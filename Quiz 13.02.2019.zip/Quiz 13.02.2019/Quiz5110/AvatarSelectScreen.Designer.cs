﻿namespace Quiz5110
{
    partial class AvatarSelectScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xbtnNext = new System.Windows.Forms.Button();
            this.xlblQuestionOneTask = new System.Windows.Forms.Label();
            this.xpcbAvatar4 = new System.Windows.Forms.PictureBox();
            this.xpcbAvatar3 = new System.Windows.Forms.PictureBox();
            this.xpcbAvatar2 = new System.Windows.Forms.PictureBox();
            this.xpcbAvatar1 = new System.Windows.Forms.PictureBox();
            this.xpctbxRightArrow = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxRightArrow)).BeginInit();
            this.SuspendLayout();
            // 
            // xbtnNext
            // 
            this.xbtnNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnNext.Location = new System.Drawing.Point(221, 346);
            this.xbtnNext.Name = "xbtnNext";
            this.xbtnNext.Size = new System.Drawing.Size(200, 75);
            this.xbtnNext.TabIndex = 7;
            this.xbtnNext.Text = "Next";
            this.xbtnNext.UseVisualStyleBackColor = true;
            this.xbtnNext.Click += new System.EventHandler(this.xbtnNext_Click);
            // 
            // xlblQuestionOneTask
            // 
            this.xlblQuestionOneTask.AutoSize = true;
            this.xlblQuestionOneTask.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblQuestionOneTask.Location = new System.Drawing.Point(175, 60);
            this.xlblQuestionOneTask.Name = "xlblQuestionOneTask";
            this.xlblQuestionOneTask.Size = new System.Drawing.Size(296, 31);
            this.xlblQuestionOneTask.TabIndex = 6;
            this.xlblQuestionOneTask.Text = "Please select an avatar";
            // 
            // xpcbAvatar4
            // 
            this.xpcbAvatar4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xpcbAvatar4.Image = global::Quiz5110.Properties.Resources.Avatar4;
            this.xpcbAvatar4.Location = new System.Drawing.Point(497, 169);
            this.xpcbAvatar4.Name = "xpcbAvatar4";
            this.xpcbAvatar4.Size = new System.Drawing.Size(100, 100);
            this.xpcbAvatar4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpcbAvatar4.TabIndex = 11;
            this.xpcbAvatar4.TabStop = false;
            this.xpcbAvatar4.Click += new System.EventHandler(this.xAvatar_Click);
            // 
            // xpcbAvatar3
            // 
            this.xpcbAvatar3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xpcbAvatar3.Image = global::Quiz5110.Properties.Resources.Avatar3;
            this.xpcbAvatar3.Location = new System.Drawing.Point(351, 169);
            this.xpcbAvatar3.Name = "xpcbAvatar3";
            this.xpcbAvatar3.Size = new System.Drawing.Size(100, 100);
            this.xpcbAvatar3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpcbAvatar3.TabIndex = 10;
            this.xpcbAvatar3.TabStop = false;
            this.xpcbAvatar3.Click += new System.EventHandler(this.xAvatar_Click);
            // 
            // xpcbAvatar2
            // 
            this.xpcbAvatar2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xpcbAvatar2.Image = global::Quiz5110.Properties.Resources.Avatar2;
            this.xpcbAvatar2.Location = new System.Drawing.Point(198, 169);
            this.xpcbAvatar2.Name = "xpcbAvatar2";
            this.xpcbAvatar2.Size = new System.Drawing.Size(100, 100);
            this.xpcbAvatar2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpcbAvatar2.TabIndex = 9;
            this.xpcbAvatar2.TabStop = false;
            this.xpcbAvatar2.Click += new System.EventHandler(this.xAvatar_Click);
            // 
            // xpcbAvatar1
            // 
            this.xpcbAvatar1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xpcbAvatar1.Image = global::Quiz5110.Properties.Resources.Avatar1;
            this.xpcbAvatar1.Location = new System.Drawing.Point(44, 169);
            this.xpcbAvatar1.Name = "xpcbAvatar1";
            this.xpcbAvatar1.Size = new System.Drawing.Size(100, 100);
            this.xpcbAvatar1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpcbAvatar1.TabIndex = 8;
            this.xpcbAvatar1.TabStop = false;
            this.xpcbAvatar1.Click += new System.EventHandler(this.xAvatar_Click);
            // 
            // xpctbxRightArrow
            // 
            this.xpctbxRightArrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xpctbxRightArrow.Image = global::Quiz5110.Properties.Resources.RightArrow;
            this.xpctbxRightArrow.Location = new System.Drawing.Point(277, 377);
            this.xpctbxRightArrow.Name = "xpctbxRightArrow";
            this.xpctbxRightArrow.Size = new System.Drawing.Size(86, 67);
            this.xpctbxRightArrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpctbxRightArrow.TabIndex = 13;
            this.xpctbxRightArrow.TabStop = false;
            this.xpctbxRightArrow.Click += new System.EventHandler(this.xbtnNext_Click);
            this.xpctbxRightArrow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.xpctbxRightArrow_MouseDown);
            this.xpctbxRightArrow.MouseEnter += new System.EventHandler(this.xpctbxRightArrow_MouseEnter);
            this.xpctbxRightArrow.MouseLeave += new System.EventHandler(this.xpctbxRightArrow_MouseLeave);
            this.xpctbxRightArrow.MouseUp += new System.Windows.Forms.MouseEventHandler(this.xpctbxRightArrow_MouseUp);
            // 
            // AvatarSelectScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.Controls.Add(this.xpctbxRightArrow);
            this.Controls.Add(this.xpcbAvatar4);
            this.Controls.Add(this.xbtnNext);
            this.Controls.Add(this.xpcbAvatar3);
            this.Controls.Add(this.xpcbAvatar2);
            this.Controls.Add(this.xpcbAvatar1);
            this.Controls.Add(this.xlblQuestionOneTask);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AvatarSelectScreen";
            this.Text = "AvatarSelectScreen";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xKeyPressed);
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxRightArrow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox xpcbAvatar4;
        private System.Windows.Forms.Button xbtnNext;
        private System.Windows.Forms.PictureBox xpcbAvatar3;
        private System.Windows.Forms.PictureBox xpcbAvatar2;
        private System.Windows.Forms.PictureBox xpcbAvatar1;
        private System.Windows.Forms.Label xlblQuestionOneTask;
        private System.Windows.Forms.PictureBox xpctbxRightArrow;
    }
}