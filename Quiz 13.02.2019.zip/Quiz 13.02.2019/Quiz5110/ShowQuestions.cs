﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Quiz5110
{
    public partial class ShowQuestions : Form
    {
        public ShowQuestions()
        {
            InitializeComponent();
            ShowQuestionsM();
        }

        private void ShowQuestionsM()
        {
            Questions questions = new Questions();
            questions.Main();
            string[,] questionsArray = questions.quiz1QuestionsPublic;
            questionsArray = DeepClone(questionsArray);
            //string[,] questionsArrayCombined = new string[questionsArray.GetLength(0), questionsArray.GetLength(1)];
            for (int i = 0; i < questionsArray.GetLength(0); i++)
            {
                for (int b = 0; b < questionsArray.GetLength(1); b++)
                {
                    xlstbxQuestions.Items.Add(questionsArray[i, b]);
                }
            }
        }

        public static T DeepClone<T>(T obj)
        {
            MemoryStream ms = new MemoryStream();
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ms, obj);
            ms.Position = 0;
            return (T)bf.Deserialize(ms);
        }
    }
}
