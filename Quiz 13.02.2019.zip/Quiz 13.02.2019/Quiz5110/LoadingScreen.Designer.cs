﻿namespace Quiz5110
{
    partial class LoadingScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xpgbLoadingBar = new System.Windows.Forms.ProgressBar();
            this.xlblLoadingText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // xpgbLoadingBar
            // 
            this.xpgbLoadingBar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.xpgbLoadingBar.Location = new System.Drawing.Point(96, 229);
            this.xpgbLoadingBar.Name = "xpgbLoadingBar";
            this.xpgbLoadingBar.Size = new System.Drawing.Size(448, 23);
            this.xpgbLoadingBar.TabIndex = 1;
            // 
            // xlblLoadingText
            // 
            this.xlblLoadingText.AutoSize = true;
            this.xlblLoadingText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblLoadingText.Location = new System.Drawing.Point(277, 187);
            this.xlblLoadingText.Name = "xlblLoadingText";
            this.xlblLoadingText.Size = new System.Drawing.Size(107, 25);
            this.xlblLoadingText.TabIndex = 2;
            this.xlblLoadingText.Text = "Loading...";
            // 
            // LoadingScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.Controls.Add(this.xpgbLoadingBar);
            this.Controls.Add(this.xlblLoadingText);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LoadingScreen";
            this.Text = "LoadingScreen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar xpgbLoadingBar;
        private System.Windows.Forms.Label xlblLoadingText;
    }
}