﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz5110
{
    public partial class AvatarSelectScreen : Form
    {
        private static string username1;
        public static string avatarName;
        private static bool firstSet = true;

        public AvatarSelectScreen(string username)
        {
            InitializeComponent();
            username1 = username;
            xbtnNext.Hide();
            xpctbxRightArrow.Hide();
            firstSet = true;
        }

        private void xbtnNext_Click(object sender, EventArgs e)
        {
            if (firstSet == false)
            {
                string username = username1;
                MenuScreen menuScreen = new MenuScreen(username);
                menuScreen.MdiParent = this.ParentForm;
                menuScreen.Dock = DockStyle.Fill;
                menuScreen.Show();
                firstSet = true;
                this.Close();
            }
        }

        private void xAvatar_Click(object sender, EventArgs e)
        {
            if (firstSet == false)
            {
                this.Controls.Find(avatarName, true)[0].Top = this.Controls.Find(avatarName, true)[0].Top + 13;
                this.Controls.Find(avatarName, true)[0].Left = this.Controls.Find(avatarName, true)[0].Left + 13;
                this.Controls.Find(avatarName, true)[0].Size = new Size(100, 100);
            }

            PictureBox avatar = (PictureBox)sender;
            avatar.Size = new Size(126, 126);
            avatar.Top = avatar.Top - 13;
            avatar.Left = avatar.Left - 13;
            avatarName = avatar.Name;
            xpctbxRightArrow.Show();
            firstSet = false;
        }

        private void xKeyPressed(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                xbtnNext_Click(sender, e);
            }
        }

        private void xpctbxRightArrow_MouseEnter(object sender, EventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrowHover;
        }

        private void xpctbxRightArrow_MouseLeave(object sender, EventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrow;
        }

        private void xpctbxRightArrow_MouseDown(object sender, MouseEventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrowClick;
        }

        private void xpctbxRightArrow_MouseUp(object sender, MouseEventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrow;
        }
    }
}
