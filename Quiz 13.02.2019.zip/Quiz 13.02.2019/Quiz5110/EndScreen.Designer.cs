﻿namespace Quiz5110
{
    partial class EndScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xpcbAvatar = new System.Windows.Forms.PictureBox();
            this.xbtnLeaderboard = new System.Windows.Forms.Button();
            this.xbtnMenu = new System.Windows.Forms.Button();
            this.xlblThanks = new System.Windows.Forms.Label();
            this.xlblFinishing = new System.Windows.Forms.Label();
            this.xbtnExit = new System.Windows.Forms.Button();
            this.xlblScoreText = new System.Windows.Forms.Label();
            this.xlblCongratulations = new System.Windows.Forms.Label();
            this.xpctbxBackground = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxBackground)).BeginInit();
            this.SuspendLayout();
            // 
            // xpcbAvatar
            // 
            this.xpcbAvatar.BackColor = System.Drawing.SystemColors.Control;
            this.xpcbAvatar.Location = new System.Drawing.Point(542, 12);
            this.xpcbAvatar.Name = "xpcbAvatar";
            this.xpcbAvatar.Size = new System.Drawing.Size(75, 75);
            this.xpcbAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpcbAvatar.TabIndex = 28;
            this.xpcbAvatar.TabStop = false;
            // 
            // xbtnLeaderboard
            // 
            this.xbtnLeaderboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnLeaderboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnLeaderboard.Location = new System.Drawing.Point(220, 377);
            this.xbtnLeaderboard.Name = "xbtnLeaderboard";
            this.xbtnLeaderboard.Size = new System.Drawing.Size(200, 75);
            this.xbtnLeaderboard.TabIndex = 26;
            this.xbtnLeaderboard.Text = "Leaderboard";
            this.xbtnLeaderboard.UseVisualStyleBackColor = true;
            this.xbtnLeaderboard.Click += new System.EventHandler(this.xbtnLeaderboard_Click);
            // 
            // xbtnMenu
            // 
            this.xbtnMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnMenu.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.xbtnMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnMenu.Location = new System.Drawing.Point(14, 377);
            this.xbtnMenu.Name = "xbtnMenu";
            this.xbtnMenu.Size = new System.Drawing.Size(200, 75);
            this.xbtnMenu.TabIndex = 25;
            this.xbtnMenu.Text = "Menu";
            this.xbtnMenu.UseVisualStyleBackColor = true;
            this.xbtnMenu.Click += new System.EventHandler(this.xbtnMenu_Click);
            // 
            // xlblThanks
            // 
            this.xlblThanks.AutoSize = true;
            this.xlblThanks.BackColor = System.Drawing.SystemColors.Control;
            this.xlblThanks.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblThanks.Location = new System.Drawing.Point(202, 286);
            this.xlblThanks.Name = "xlblThanks";
            this.xlblThanks.Size = new System.Drawing.Size(162, 20);
            this.xlblThanks.TabIndex = 21;
            this.xlblThanks.Text = "Thank you for playing!";
            // 
            // xlblFinishing
            // 
            this.xlblFinishing.AutoSize = true;
            this.xlblFinishing.BackColor = System.Drawing.SystemColors.Control;
            this.xlblFinishing.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblFinishing.Location = new System.Drawing.Point(202, 185);
            this.xlblFinishing.Name = "xlblFinishing";
            this.xlblFinishing.Size = new System.Drawing.Size(247, 20);
            this.xlblFinishing.TabIndex = 22;
            this.xlblFinishing.Text = "[Username], you finished the quiz!";
            // 
            // xbtnExit
            // 
            this.xbtnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnExit.Location = new System.Drawing.Point(426, 377);
            this.xbtnExit.Name = "xbtnExit";
            this.xbtnExit.Size = new System.Drawing.Size(200, 75);
            this.xbtnExit.TabIndex = 27;
            this.xbtnExit.Text = "Exit";
            this.xbtnExit.UseVisualStyleBackColor = true;
            this.xbtnExit.Click += new System.EventHandler(this.xbtnExit_Click);
            // 
            // xlblScoreText
            // 
            this.xlblScoreText.AutoSize = true;
            this.xlblScoreText.BackColor = System.Drawing.SystemColors.Control;
            this.xlblScoreText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblScoreText.Location = new System.Drawing.Point(202, 237);
            this.xlblScoreText.Name = "xlblScoreText";
            this.xlblScoreText.Size = new System.Drawing.Size(363, 20);
            this.xlblScoreText.TabIndex = 23;
            this.xlblScoreText.Text = "You scored [Score] out of [MaximumPoints] points!";
            // 
            // xlblCongratulations
            // 
            this.xlblCongratulations.AutoSize = true;
            this.xlblCongratulations.BackColor = System.Drawing.SystemColors.Control;
            this.xlblCongratulations.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblCongratulations.Location = new System.Drawing.Point(184, 62);
            this.xlblCongratulations.Name = "xlblCongratulations";
            this.xlblCongratulations.Size = new System.Drawing.Size(270, 39);
            this.xlblCongratulations.TabIndex = 24;
            this.xlblCongratulations.Text = "Congratulations!";
            // 
            // xpctbxBackground
            // 
            this.xpctbxBackground.Image = global::Quiz5110.Properties.Resources.Stars;
            this.xpctbxBackground.Location = new System.Drawing.Point(-1, 0);
            this.xpctbxBackground.Name = "xpctbxBackground";
            this.xpctbxBackground.Size = new System.Drawing.Size(641, 483);
            this.xpctbxBackground.TabIndex = 29;
            this.xpctbxBackground.TabStop = false;
            // 
            // EndScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.Controls.Add(this.xpcbAvatar);
            this.Controls.Add(this.xbtnLeaderboard);
            this.Controls.Add(this.xbtnMenu);
            this.Controls.Add(this.xlblThanks);
            this.Controls.Add(this.xlblFinishing);
            this.Controls.Add(this.xbtnExit);
            this.Controls.Add(this.xlblScoreText);
            this.Controls.Add(this.xlblCongratulations);
            this.Controls.Add(this.xpctbxBackground);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EndScreen";
            this.Text = "EndScreen";
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxBackground)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox xpcbAvatar;
        private System.Windows.Forms.Button xbtnLeaderboard;
        private System.Windows.Forms.Button xbtnMenu;
        private System.Windows.Forms.Label xlblThanks;
        private System.Windows.Forms.Label xlblFinishing;
        private System.Windows.Forms.Button xbtnExit;
        private System.Windows.Forms.Label xlblScoreText;
        private System.Windows.Forms.Label xlblCongratulations;
        private System.Windows.Forms.PictureBox xpctbxBackground;
    }
}