﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz5110
{
    public partial class QuestionRadioButtonScreen : Form
    {

        public static int RadioQuestionCount = 0;
        private List<Question> _questions = new List<Question>();
        private List<int> questionOrder = new List<int>();
        private int _currentQuestion = 0;
        private int questionNumber = 0;
        private Random random = new Random();
        private System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();

        public QuestionRadioButtonScreen()
        {
            InitializeComponent();
            SetAvatar();
            SetQuiz();
            xbtnNext.Hide();
            xlblScore.Text = ($"Score: {MenuScreen.Player.score}");
        }

        private void SetQuiz()
        {
            if (HolderForm.QuizNumber == 1)
            {
                Quiz1();
            }
            else if (HolderForm.QuizNumber == 2)
            {
                Quiz2();
            }
            else if (HolderForm.QuizNumber == 3)
            {
                Quiz3();
            }
        }

        private void SetAvatar()
        {
            if (AvatarSelectScreen.avatarName == "xpcbAvatar1")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar1;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar2")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar2;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar3")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar3;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar4")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar4;
                xpcbAvatar.Refresh();
            }
        }

        private void Quiz1()
        {
            _questions.Add(new Question("What is meant by the term 'internet of things'?",
                new[] { "Everything on the internet", "Every-day objects connected\nthrough the internet", "Websites on the internet", "Desktops, laptops, smartphones etcetera\nconnected through the internet" }, 2));

            CheckIfQuestionsExist();
        }

        private void Quiz2()
        {
            CheckIfQuestionsExist();
        }

        private void Quiz3()
        {
            CheckIfQuestionsExist();
        }

        private void CheckIfQuestionsExist()
        {
            RadioQuestionCount = _questions.Count();
            if (RadioQuestionCount > 0)
            {
                SetQuestionOrder();
                NextQuestion();
            }
            else
            {
                timer.Tick += new EventHandler(Timer_Tick);
                timer.Interval = 2;
                timer.Start();
                //Todo: Prevent this form for appearing for a couple of frames - add questions...
                //to text file and check from menu to determine if this form should open or not
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            NextQuestionType();
        }

        private void xRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (xrdbtnAnswer1.Checked == true || xrdbtnAnswer2.Checked == true || xrdbtnAnswer3.Checked == true || xrdbtnAnswer4.Checked == true)
            {
                xpctbxRightArrow.Show();
            }
        }

        private void NextQuestion()
        {

            string[] answers = _questions[_currentQuestion].Answers;

            xrdbtnAnswer1.Hide();
            xrdbtnAnswer2.Hide();
            xrdbtnAnswer3.Hide();
            xrdbtnAnswer4.Hide();
            xpctbxRightArrow.Hide();

            if (answers.ElementAtOrDefault(0) != null)
            {
                xlblRadioQuestionText.Text = _questions[_currentQuestion].QuestionText;
                xrdbtnAnswer1.Text = answers[0];
                xrdbtnAnswer1.Show();
            }
            if (answers.ElementAtOrDefault(1) != null)
            {
                xrdbtnAnswer2.Text = answers[1];
                xrdbtnAnswer2.Show();
            }
            if (answers.ElementAtOrDefault(2) != null)
            {
                xrdbtnAnswer3.Text = answers[2];
                xrdbtnAnswer3.Show();
            }
            if (answers.ElementAtOrDefault(3) != null)
            {
                xrdbtnAnswer4.Text = answers[3];
                xrdbtnAnswer4.Show();
            }
        }

        private void xbtnNext_Click(object sender, EventArgs e)
        {
            SetSelectedAnswer();
        }

        private void SetSelectedAnswer()
        {
            int answer = 0;
            if (xrdbtnAnswer1.Checked == true)
            {
                answer = 1;
            }
            if (xrdbtnAnswer2.Checked == true)
            {
                answer = 2;
            }
            if (xrdbtnAnswer3.Checked == true)
            {
                answer = 3;
            }
            if (xrdbtnAnswer4.Checked == true)
            {
                answer = 4;
            }
            xrdbtnAnswer1.Checked = false;
            xrdbtnAnswer2.Checked = false;
            xrdbtnAnswer3.Checked = false;
            xrdbtnAnswer4.Checked = false;
            CheckAnswer(answer);
        }

        private int RandomNumber()
        {
            lock (random)
            {
                return random.Next(0, RadioQuestionCount);
            }
        }

        private void SetQuestionOrder()
        {
            for (int i = 0; i < RadioQuestionCount; i++)
            {
                questionOrder.Add(RandomNumber());
                while (questionOrder.IndexOf(questionOrder.ElementAtOrDefault(i)) != i)
                {
                    questionOrder[i] = RandomNumber();
                }
            }

            _currentQuestion = questionOrder.ElementAtOrDefault(0);
        }

        private void CheckAnswer(int answer)
        {
            if (RadioQuestionCount > 0)
            {
                if (answer == _questions[_currentQuestion].CorrectAnswerPosition)
                {
                    MenuScreen.Player.IncreaseScore();
                    xlblScore.Text = ($"Score: {MenuScreen.Player.score}");
                }

                questionNumber++;
                _currentQuestion = questionOrder.ElementAtOrDefault(questionNumber);
            }

            if (questionNumber < _questions.Count)
            {
                NextQuestion();
            }
            else
            {
                NextQuestionType();
            }
        }

        private void NextQuestionType()
        {
            HolderForm.CurrentQuestionTypeNumber++;

            if (HolderForm.CurrentQuestionTypeNumber == HolderForm.TickBoxPosition)
            {
                QuestionTickboxScreen tickboxScreen = new QuestionTickboxScreen();
                tickboxScreen.MdiParent = this.ParentForm;
                tickboxScreen.Dock = DockStyle.Fill;
                tickboxScreen.Show();
                this.Close();
            }
            else if (HolderForm.CurrentQuestionTypeNumber == HolderForm.RadioPosition)
            {
                QuestionRadioButtonScreen radioButtonScreen = new QuestionRadioButtonScreen();
                radioButtonScreen.MdiParent = this.ParentForm;
                radioButtonScreen.Dock = DockStyle.Fill;
                radioButtonScreen.Show();
                this.Close();
            }
            else if (HolderForm.CurrentQuestionTypeNumber == HolderForm.DragAndDropPosition)
            {
                QuestionDragAndDropScreen dragAndDropScreen = new QuestionDragAndDropScreen();
                dragAndDropScreen.MdiParent = this.ParentForm;
                dragAndDropScreen.Dock = DockStyle.Fill;
                dragAndDropScreen.Show();
                this.Close();
            }
            else if (HolderForm.CurrentQuestionTypeNumber == 4)
            {
                EndScreen endScreen = new EndScreen(true); //EndScreen();
                endScreen.MdiParent = this.ParentForm;
                endScreen.Dock = DockStyle.Fill;
                endScreen.Show();
                this.Close();
            }
        }

        private void xpctbxRightArrow_MouseEnter(object sender, EventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrowHover;
        }

        private void xpctbxRightArrow_MouseLeave(object sender, EventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrow;
        }

        private void xpctbxRightArrow_MouseDown(object sender, MouseEventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrowClick;
        }

        private void xpctbxRightArrow_MouseUp(object sender, MouseEventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrow;
        }
    }
}