﻿namespace Quiz5110
{
    partial class Debug
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xDragAndDropPosition = new System.Windows.Forms.Label();
            this.xRadioButtonPosition = new System.Windows.Forms.Label();
            this.xTickBoxPosition = new System.Windows.Forms.Label();
            this.xCurrentQuestionTypeNumber = new System.Windows.Forms.Label();
            this.xQuizNumber = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // xDragAndDropPosition
            // 
            this.xDragAndDropPosition.AutoSize = true;
            this.xDragAndDropPosition.Location = new System.Drawing.Point(12, 126);
            this.xDragAndDropPosition.Name = "xDragAndDropPosition";
            this.xDragAndDropPosition.Size = new System.Drawing.Size(118, 13);
            this.xDragAndDropPosition.TabIndex = 9;
            this.xDragAndDropPosition.Text = "DragAndDropPosition =";
            // 
            // xRadioButtonPosition
            // 
            this.xRadioButtonPosition.AutoSize = true;
            this.xRadioButtonPosition.Location = new System.Drawing.Point(12, 97);
            this.xRadioButtonPosition.Name = "xRadioButtonPosition";
            this.xRadioButtonPosition.Size = new System.Drawing.Size(112, 13);
            this.xRadioButtonPosition.TabIndex = 8;
            this.xRadioButtonPosition.Text = "RadioButtonPosition =";
            // 
            // xTickBoxPosition
            // 
            this.xTickBoxPosition.AutoSize = true;
            this.xTickBoxPosition.Location = new System.Drawing.Point(12, 64);
            this.xTickBoxPosition.Name = "xTickBoxPosition";
            this.xTickBoxPosition.Size = new System.Drawing.Size(92, 13);
            this.xTickBoxPosition.TabIndex = 7;
            this.xTickBoxPosition.Text = "TickBoxPosition =";
            // 
            // xCurrentQuestionTypeNumber
            // 
            this.xCurrentQuestionTypeNumber.AutoSize = true;
            this.xCurrentQuestionTypeNumber.Location = new System.Drawing.Point(11, 35);
            this.xCurrentQuestionTypeNumber.Name = "xCurrentQuestionTypeNumber";
            this.xCurrentQuestionTypeNumber.Size = new System.Drawing.Size(153, 13);
            this.xCurrentQuestionTypeNumber.TabIndex = 6;
            this.xCurrentQuestionTypeNumber.Text = "CurrentQuestionTypeNumber =";
            // 
            // xQuizNumber
            // 
            this.xQuizNumber.AutoSize = true;
            this.xQuizNumber.Location = new System.Drawing.Point(12, 9);
            this.xQuizNumber.Name = "xQuizNumber";
            this.xQuizNumber.Size = new System.Drawing.Size(74, 13);
            this.xQuizNumber.TabIndex = 5;
            this.xQuizNumber.Text = "QuizNumber =";
            // 
            // Debug
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.xDragAndDropPosition);
            this.Controls.Add(this.xRadioButtonPosition);
            this.Controls.Add(this.xTickBoxPosition);
            this.Controls.Add(this.xCurrentQuestionTypeNumber);
            this.Controls.Add(this.xQuizNumber);
            this.Name = "Debug";
            this.Text = "Debug";
            this.Load += new System.EventHandler(this.Debug_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label xDragAndDropPosition;
        private System.Windows.Forms.Label xRadioButtonPosition;
        private System.Windows.Forms.Label xTickBoxPosition;
        private System.Windows.Forms.Label xCurrentQuestionTypeNumber;
        private System.Windows.Forms.Label xQuizNumber;
    }
}