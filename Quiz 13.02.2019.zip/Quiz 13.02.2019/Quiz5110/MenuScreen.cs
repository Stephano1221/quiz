﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Quiz5110
{
    public partial class MenuScreen : Form
    {
        private Random random = new Random();
        private static string username1;

        public MenuScreen(string username)
        {
            InitializeComponent();
            xlblQuizTitle.Hide();
            username1 = username;
            Player = new Player(username);
            xlblWelcome.Text = ($"Welcome, {username}, to the quiz!");
            ResetVariables();
            AddMenuAndItems();
            SetAvatar();
            GetLastScore();
            HolderForm.comingFrom = "MenuScreen";
        }

        public static Player Player;

        private void ResetVariables()
        {
            HolderForm.QuizNumber = 0;
            HolderForm.CurrentQuestionTypeNumber = 1;
            HolderForm.TickBoxPosition = 0;
            HolderForm.RadioPosition = 0;
            HolderForm.DragAndDropPosition = 0;
        }
        private void AddMenuAndItems()
        {
            if (LoginScreen.userFound == false)
            {
                (xmsMenu.Items[0] as ToolStripMenuItem).DropDownItems.Add("Logout");
                (xmsMenu.Items[0] as ToolStripMenuItem).DropDownItems.Add("Exit");
                xlblLastScore.Hide();
            }
            else if (LoginScreen.userFound == true)
            {
                (xmsMenu.Items[0] as ToolStripMenuItem).DropDownItems.Add("Logout");
                (xmsMenu.Items[0] as ToolStripMenuItem).DropDownItems.Add("Register");
                (xmsMenu.Items[0] as ToolStripMenuItem).DropDownItems.Add("Leaderboard");
                (xmsMenu.Items[0] as ToolStripMenuItem).DropDownItems.Add("Exit");
            }
        }

        private void SetAvatar()
        {
            if (AvatarSelectScreen.avatarName == "xpcbAvatar1")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar1;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar2")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar2;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar3")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar3;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar4")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar4;
                xpcbAvatar.Refresh();
            }
        }

        private void xMenuDropDownItem_Click(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem.Text == "Logout")
            {
                Logout();
            }
            else if (e.ClickedItem.Text == "Register")
            {
                Register();
            }
            else if (e.ClickedItem.Text == "Leaderboard")
            {
                Leaderboard();
            }
            else if (e.ClickedItem.Text == "Exit")
            {
                Exit();
            }
        }

        /*private void CheckQuestionCount()
        {
            if (File.Exists($"questions.txt"))
            {
                StreamReader sr = new StreamReader("questions.txt");
                Regex regex = new Regex("~");
                int numLinesInFile = File.ReadLines("questions.txt").Count();
                int quiz1Count, quiz2Count, quiz3Count;

                while (sr.Peek() >= 0)
                {
                    string[] seperators = { "~" };

                    for (int i = 0; i < numLinesInFile; i++)
                    {
                        string readLine = sr.ReadLine();
                        if (readLine.Contains(""))
                        {

                        }
                    }
                }
            }
        }*/

        private void SetQuestionTypeOrder()
        {
            HolderForm.TickBoxPosition = randomNumber();
            HolderForm.RadioPosition = randomNumber();
            HolderForm.DragAndDropPosition = randomNumber();

            while (HolderForm.RadioPosition == HolderForm.TickBoxPosition)
            {
                HolderForm.RadioPosition = randomNumber();
            }

            while ((HolderForm.DragAndDropPosition == HolderForm.TickBoxPosition) || (HolderForm.DragAndDropPosition == HolderForm.RadioPosition))
            {
                HolderForm.DragAndDropPosition = randomNumber();
            }

            NewQuestionScreen();
        }

        private int randomNumber()
        {
            lock (random)
            {
                return random.Next(1, 4);
            }
        }

        private void NewQuestionScreen()
        {
            if (HolderForm.TickBoxPosition == 1)
            {
                QuestionTickboxScreen questionTickBoxScreen = new QuestionTickboxScreen();
                questionTickBoxScreen.MdiParent = this.ParentForm;
                questionTickBoxScreen.Dock = DockStyle.Fill;
                questionTickBoxScreen.Show();
                this.Close();
            }
            if (HolderForm.RadioPosition == 1)
            {
                QuestionRadioButtonScreen questionRadioButtonScreen = new QuestionRadioButtonScreen();
                questionRadioButtonScreen.MdiParent = this.ParentForm;
                questionRadioButtonScreen.Dock = DockStyle.Fill;
                questionRadioButtonScreen.Show();
                this.Close();
            }
            if (HolderForm.DragAndDropPosition == 1)
            {
                QuestionDragAndDropScreen questionDragAndDropScreen = new QuestionDragAndDropScreen();
                questionDragAndDropScreen.MdiParent = this.ParentForm;
                questionDragAndDropScreen.Dock = DockStyle.Fill;
                questionDragAndDropScreen.Show();
                this.Close();
            }
        }

        private void GetLastScore()
        {
            Player deserializedPlayer = Serializer.DeserializePlayer();

            if (deserializedPlayer != null)
            {
                xlblLastScore.Text = ($"Last Score:\n{deserializedPlayer.username} scored {deserializedPlayer.score} out of {deserializedPlayer.totalQuestionCount}");
            }
            else
            {
                xlblLastScore.Visible = false;
            }
        }

        private void xbtnNetworks_Click(object sender, EventArgs e)
        {
            HolderForm.QuizNumber = 1;
            SetQuestionTypeOrder();
        }

        private void xbtnWirelessTechnologies_Click(object sender, EventArgs e)
        {
            HolderForm.QuizNumber = 2;
            SetQuestionTypeOrder();
        }

        private void xbtnComputerHardware_Click(object sender, EventArgs e)
        {
            HolderForm.QuizNumber = 3;
            SetQuestionTypeOrder();
        }

        private void Logout()
        {
            LoginScreen loginScreen = new LoginScreen();
            loginScreen.MdiParent = this.ParentForm;
            loginScreen.Dock = DockStyle.Fill;
            loginScreen.Show();
            LoginScreen.userFound = false;
            this.Close();
        }

        private void Register()
        {
            RegisterScreen registerScreen = new RegisterScreen(username1);
            registerScreen.MdiParent = this.ParentForm;
            registerScreen.Dock = DockStyle.Fill;
            registerScreen.Show();
            this.Close();
        }

        private void Leaderboard()
        {
            LeaderboardScreen leaderboard = new LeaderboardScreen();
            leaderboard.MdiParent = this.ParentForm;
            leaderboard.Dock = DockStyle.Fill;
            leaderboard.Show();
            this.Close();
        }

        private void Exit()
        {
            System.Windows.Forms.Application.Exit();
        }

        //Todo: Change cursor to hand when cursor is over Menu button items
        
        private void xMouseEnter(object sender, EventArgs e)
        {
            //System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Hand;
            xmsMenu.Cursor = Cursors.Hand;
        }

        private void xMouseLeave(object sender, EventArgs e)
        {
            //System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
            xmsMenu.Cursor = Cursors.Default;
        }
    }
}