﻿namespace Quiz5110
{
    partial class LeaderboardScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LeaderboardScreen));
            this.xlblDate = new System.Windows.Forms.Label();
            this.xlblScore = new System.Windows.Forms.Label();
            this.xlblSortBy = new System.Windows.Forms.Label();
            this.xbtnBack = new System.Windows.Forms.Button();
            this.xlstbxLeaderboard = new System.Windows.Forms.ListBox();
            this.xlblLeaderboard = new System.Windows.Forms.Label();
            this.xpctbxDown = new System.Windows.Forms.PictureBox();
            this.xpctbxUp = new System.Windows.Forms.PictureBox();
            this.xpctbxLeftArrow = new System.Windows.Forms.PictureBox();
            this.xpcbAvatar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxUp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxLeftArrow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).BeginInit();
            this.SuspendLayout();
            // 
            // xlblDate
            // 
            this.xlblDate.AutoSize = true;
            this.xlblDate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xlblDate.Location = new System.Drawing.Point(158, 84);
            this.xlblDate.Name = "xlblDate";
            this.xlblDate.Size = new System.Drawing.Size(30, 13);
            this.xlblDate.TabIndex = 34;
            this.xlblDate.Text = "Date";
            this.xlblDate.Click += new System.EventHandler(this.xlblDate_Clicked);
            // 
            // xlblScore
            // 
            this.xlblScore.AutoSize = true;
            this.xlblScore.BackColor = System.Drawing.SystemColors.Control;
            this.xlblScore.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xlblScore.Location = new System.Drawing.Point(117, 84);
            this.xlblScore.Name = "xlblScore";
            this.xlblScore.Size = new System.Drawing.Size(35, 13);
            this.xlblScore.TabIndex = 33;
            this.xlblScore.Text = "Score";
            this.xlblScore.Click += new System.EventHandler(this.xlblScore_Clicked);
            // 
            // xlblSortBy
            // 
            this.xlblSortBy.AutoSize = true;
            this.xlblSortBy.Location = new System.Drawing.Point(68, 84);
            this.xlblSortBy.Name = "xlblSortBy";
            this.xlblSortBy.Size = new System.Drawing.Size(43, 13);
            this.xlblSortBy.TabIndex = 32;
            this.xlblSortBy.Text = "Sort by:";
            // 
            // xbtnBack
            // 
            this.xbtnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.xbtnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnBack.Location = new System.Drawing.Point(217, 377);
            this.xbtnBack.Name = "xbtnBack";
            this.xbtnBack.Size = new System.Drawing.Size(200, 75);
            this.xbtnBack.TabIndex = 30;
            this.xbtnBack.Text = "Back";
            this.xbtnBack.UseVisualStyleBackColor = true;
            this.xbtnBack.Click += new System.EventHandler(this.xbtnBack_Click);
            // 
            // xlstbxLeaderboard
            // 
            this.xlstbxLeaderboard.FormattingEnabled = true;
            this.xlstbxLeaderboard.Location = new System.Drawing.Point(71, 117);
            this.xlstbxLeaderboard.Name = "xlstbxLeaderboard";
            this.xlstbxLeaderboard.Size = new System.Drawing.Size(480, 238);
            this.xlstbxLeaderboard.TabIndex = 28;
            this.xlstbxLeaderboard.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xKeyPress);
            // 
            // xlblLeaderboard
            // 
            this.xlblLeaderboard.AutoSize = true;
            this.xlblLeaderboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblLeaderboard.Location = new System.Drawing.Point(210, 28);
            this.xlblLeaderboard.Name = "xlblLeaderboard";
            this.xlblLeaderboard.Size = new System.Drawing.Size(212, 39);
            this.xlblLeaderboard.TabIndex = 29;
            this.xlblLeaderboard.Text = "Leaderboard";
            // 
            // xpctbxDown
            // 
            this.xpctbxDown.Image = ((System.Drawing.Image)(resources.GetObject("xpctbxDown.Image")));
            this.xpctbxDown.Location = new System.Drawing.Point(127, 100);
            this.xpctbxDown.Name = "xpctbxDown";
            this.xpctbxDown.Size = new System.Drawing.Size(15, 15);
            this.xpctbxDown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpctbxDown.TabIndex = 46;
            this.xpctbxDown.TabStop = false;
            // 
            // xpctbxUp
            // 
            this.xpctbxUp.Image = global::Quiz5110.Properties.Resources.UpArrow;
            this.xpctbxUp.Location = new System.Drawing.Point(165, 100);
            this.xpctbxUp.Name = "xpctbxUp";
            this.xpctbxUp.Size = new System.Drawing.Size(15, 15);
            this.xpctbxUp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpctbxUp.TabIndex = 45;
            this.xpctbxUp.TabStop = false;
            // 
            // xpctbxLeftArrow
            // 
            this.xpctbxLeftArrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xpctbxLeftArrow.Image = global::Quiz5110.Properties.Resources.LeftArrow;
            this.xpctbxLeftArrow.Location = new System.Drawing.Point(277, 377);
            this.xpctbxLeftArrow.Name = "xpctbxLeftArrow";
            this.xpctbxLeftArrow.Size = new System.Drawing.Size(86, 67);
            this.xpctbxLeftArrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpctbxLeftArrow.TabIndex = 44;
            this.xpctbxLeftArrow.TabStop = false;
            this.xpctbxLeftArrow.Click += new System.EventHandler(this.xbtnBack_Click);
            this.xpctbxLeftArrow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.xpctbxLeftArrow_MouseDown);
            this.xpctbxLeftArrow.MouseEnter += new System.EventHandler(this.xpctbxLeftArrow_MouseEnter);
            this.xpctbxLeftArrow.MouseLeave += new System.EventHandler(this.xpctbxLeftArrow_MouseLeave);
            this.xpctbxLeftArrow.MouseUp += new System.Windows.Forms.MouseEventHandler(this.xpctbxLeftArrow_MouseUp);
            // 
            // xpcbAvatar
            // 
            this.xpcbAvatar.Location = new System.Drawing.Point(542, 12);
            this.xpcbAvatar.Name = "xpcbAvatar";
            this.xpcbAvatar.Size = new System.Drawing.Size(75, 75);
            this.xpcbAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpcbAvatar.TabIndex = 31;
            this.xpcbAvatar.TabStop = false;
            // 
            // LeaderboardScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.Controls.Add(this.xpctbxDown);
            this.Controls.Add(this.xpctbxUp);
            this.Controls.Add(this.xpctbxLeftArrow);
            this.Controls.Add(this.xlblDate);
            this.Controls.Add(this.xlblScore);
            this.Controls.Add(this.xlblSortBy);
            this.Controls.Add(this.xpcbAvatar);
            this.Controls.Add(this.xbtnBack);
            this.Controls.Add(this.xlstbxLeaderboard);
            this.Controls.Add(this.xlblLeaderboard);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LeaderboardScreen";
            this.Text = "LeaderboardScreen";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xKeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxUp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxLeftArrow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label xlblDate;
        private System.Windows.Forms.Label xlblScore;
        private System.Windows.Forms.Label xlblSortBy;
        private System.Windows.Forms.PictureBox xpcbAvatar;
        private System.Windows.Forms.Button xbtnBack;
        private System.Windows.Forms.ListBox xlstbxLeaderboard;
        private System.Windows.Forms.Label xlblLeaderboard;
        private System.Windows.Forms.PictureBox xpctbxLeftArrow;
        private System.Windows.Forms.PictureBox xpctbxUp;
        private System.Windows.Forms.PictureBox xpctbxDown;
    }
}