﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz5110
{
    public partial class Debug : Form
    {

        private System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();

        public Debug()
        {
            InitializeComponent();
        }

        private void Debug_Load(object sender, EventArgs e)
        {
            timer.Tick += new EventHandler(Tick);
            timer.Interval = 100;
            timer.Start();
        }

        private void Tick(object sender, EventArgs e)
        {
            xQuizNumber.Text = ($"QuizNumber: {Convert.ToString(HolderForm.QuizNumber)}");
            xCurrentQuestionTypeNumber.Text = ($"CurrentQuestionTypeNumber: {Convert.ToString(HolderForm.CurrentQuestionTypeNumber)}");
            xTickBoxPosition.Text = ($"TickBoxPosition: {Convert.ToString(HolderForm.TickBoxPosition)}");
            xRadioButtonPosition.Text = ($"RadioButtonPosition: {Convert.ToString(HolderForm.RadioPosition)}");
            xDragAndDropPosition.Text = ($"DragAndDropPosition: {Convert.ToString(HolderForm.DragAndDropPosition)}");
        }
    }
}
