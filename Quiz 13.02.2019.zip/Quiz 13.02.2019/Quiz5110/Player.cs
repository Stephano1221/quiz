﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz5110
{
    [Serializable]

    public class Player
    {
        public string username;
        public int score;
        public int totalQuestionCount;

        public Player(string name)
        {
            username = name;
            score = 0;
        }

        public void ResetPlayer()
        {
            username = "";
            score = 0;
        }

        public void IncreaseScore()
        {
            score++;
            totalQuestionCount = (QuestionTickboxScreen.TickBoxQuestionCount + QuestionRadioButtonScreen.RadioQuestionCount + QuestionDragAndDropScreen.dragAndDropQuestionCount);
        }
    }
}
