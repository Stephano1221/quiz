﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz5110
{
    public partial class LoadingScreen : Form
    {
        private System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        private Random random = new Random();

        public LoadingScreen()
        {
            InitializeComponent();
            StartTimer();
        }

        private int GetRandomNumber()
        {
            lock (random)
            {
                return random.Next(0, 11);
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            xpgbLoadingBar.Increment(GetRandomNumber());
            xlblLoadingText.Text = ($"Loading: {xpgbLoadingBar.Value}%");

            if (xpgbLoadingBar.Value >= xpgbLoadingBar.Maximum)
            {
                timer.Stop();

                //new LoginScreen().Show();
                LoginScreen loginScreen = new LoginScreen();
                loginScreen.MdiParent = this.ParentForm;
                loginScreen.Dock = DockStyle.Fill;
                loginScreen.Show();
                this.Close();
            }
        }

        private void StartTimer()
        {
            timer.Tick += new EventHandler(Timer_Tick);
            timer.Interval = 75;
            timer.Start();
        }
    }
}
