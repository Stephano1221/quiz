﻿namespace Quiz5110
{
    partial class QuestionDragAndDropScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xlblScore = new System.Windows.Forms.Label();
            this.xlblSharepoint = new System.Windows.Forms.Label();
            this.xlblWindows = new System.Windows.Forms.Label();
            this.xlblVisualStudio = new System.Windows.Forms.Label();
            this.xlblQuestionOneTask = new System.Windows.Forms.Label();
            this.xpcbAvatar = new System.Windows.Forms.PictureBox();
            this.xpcbVisualStudio = new System.Windows.Forms.PictureBox();
            this.xpcbSharepoint = new System.Windows.Forms.PictureBox();
            this.xpcbWindows = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbVisualStudio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbSharepoint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbWindows)).BeginInit();
            this.SuspendLayout();
            // 
            // xlblScore
            // 
            this.xlblScore.AutoSize = true;
            this.xlblScore.Location = new System.Drawing.Point(12, 9);
            this.xlblScore.Name = "xlblScore";
            this.xlblScore.Size = new System.Drawing.Size(38, 13);
            this.xlblScore.TabIndex = 20;
            this.xlblScore.Text = "Score:";
            // 
            // xlblSharepoint
            // 
            this.xlblSharepoint.AutoSize = true;
            this.xlblSharepoint.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.xlblSharepoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblSharepoint.Location = new System.Drawing.Point(92, 347);
            this.xlblSharepoint.Name = "xlblSharepoint";
            this.xlblSharepoint.Size = new System.Drawing.Size(87, 20);
            this.xlblSharepoint.TabIndex = 21;
            this.xlblSharepoint.Text = "Sharepoint";
            this.xlblSharepoint.DragDrop += new System.Windows.Forms.DragEventHandler(this.xLabel_DragDrop);
            this.xlblSharepoint.MouseDown += new System.Windows.Forms.MouseEventHandler(this.xControlGrabbed);
            // 
            // xlblWindows
            // 
            this.xlblWindows.AutoSize = true;
            this.xlblWindows.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.xlblWindows.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblWindows.Location = new System.Drawing.Point(92, 257);
            this.xlblWindows.Name = "xlblWindows";
            this.xlblWindows.Size = new System.Drawing.Size(73, 20);
            this.xlblWindows.TabIndex = 22;
            this.xlblWindows.Text = "Windows";
            this.xlblWindows.DragDrop += new System.Windows.Forms.DragEventHandler(this.xLabel_DragDrop);
            this.xlblWindows.MouseDown += new System.Windows.Forms.MouseEventHandler(this.xControlGrabbed);
            // 
            // xlblVisualStudio
            // 
            this.xlblVisualStudio.AutoSize = true;
            this.xlblVisualStudio.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.xlblVisualStudio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblVisualStudio.Location = new System.Drawing.Point(92, 155);
            this.xlblVisualStudio.Name = "xlblVisualStudio";
            this.xlblVisualStudio.Size = new System.Drawing.Size(102, 20);
            this.xlblVisualStudio.TabIndex = 23;
            this.xlblVisualStudio.Text = "Visual Studio";
            this.xlblVisualStudio.MouseDown += new System.Windows.Forms.MouseEventHandler(this.xControlGrabbed);
            // 
            // xlblQuestionOneTask
            // 
            this.xlblQuestionOneTask.AutoSize = true;
            this.xlblQuestionOneTask.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblQuestionOneTask.Location = new System.Drawing.Point(109, 102);
            this.xlblQuestionOneTask.Name = "xlblQuestionOneTask";
            this.xlblQuestionOneTask.Size = new System.Drawing.Size(415, 25);
            this.xlblQuestionOneTask.TabIndex = 24;
            this.xlblQuestionOneTask.Text = "Match the text to the corresponding image";
            // 
            // xpcbAvatar
            // 
            this.xpcbAvatar.Location = new System.Drawing.Point(542, 12);
            this.xpcbAvatar.Name = "xpcbAvatar";
            this.xpcbAvatar.Size = new System.Drawing.Size(75, 75);
            this.xpcbAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpcbAvatar.TabIndex = 28;
            this.xpcbAvatar.TabStop = false;
            // 
            // xpcbVisualStudio
            // 
            this.xpcbVisualStudio.Image = global::Quiz5110.Properties.Resources.VisualStudioLogo;
            this.xpcbVisualStudio.Location = new System.Drawing.Point(455, 323);
            this.xpcbVisualStudio.Name = "xpcbVisualStudio";
            this.xpcbVisualStudio.Size = new System.Drawing.Size(78, 61);
            this.xpcbVisualStudio.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.xpcbVisualStudio.TabIndex = 27;
            this.xpcbVisualStudio.TabStop = false;
            this.xpcbVisualStudio.DragDrop += new System.Windows.Forms.DragEventHandler(this.xVisualStudio_DragDrop);
            this.xpcbVisualStudio.DragEnter += new System.Windows.Forms.DragEventHandler(this.xAllowDragDropCopy);
            // 
            // xpcbSharepoint
            // 
            this.xpcbSharepoint.Image = global::Quiz5110.Properties.Resources.SharepointLogo;
            this.xpcbSharepoint.Location = new System.Drawing.Point(455, 233);
            this.xpcbSharepoint.Name = "xpcbSharepoint";
            this.xpcbSharepoint.Size = new System.Drawing.Size(78, 61);
            this.xpcbSharepoint.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.xpcbSharepoint.TabIndex = 26;
            this.xpcbSharepoint.TabStop = false;
            this.xpcbSharepoint.DragDrop += new System.Windows.Forms.DragEventHandler(this.xSharepoint_DragDrop);
            this.xpcbSharepoint.DragEnter += new System.Windows.Forms.DragEventHandler(this.xAllowDragDropCopy);
            // 
            // xpcbWindows
            // 
            this.xpcbWindows.Image = global::Quiz5110.Properties.Resources.Windows10Logo;
            this.xpcbWindows.Location = new System.Drawing.Point(455, 140);
            this.xpcbWindows.Name = "xpcbWindows";
            this.xpcbWindows.Size = new System.Drawing.Size(78, 61);
            this.xpcbWindows.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.xpcbWindows.TabIndex = 25;
            this.xpcbWindows.TabStop = false;
            this.xpcbWindows.DragDrop += new System.Windows.Forms.DragEventHandler(this.xWindows_DragDrop);
            this.xpcbWindows.DragEnter += new System.Windows.Forms.DragEventHandler(this.xAllowDragDropCopy);
            // 
            // QuestionDragAndDropScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.Controls.Add(this.xpcbAvatar);
            this.Controls.Add(this.xlblScore);
            this.Controls.Add(this.xpcbVisualStudio);
            this.Controls.Add(this.xpcbSharepoint);
            this.Controls.Add(this.xpcbWindows);
            this.Controls.Add(this.xlblSharepoint);
            this.Controls.Add(this.xlblWindows);
            this.Controls.Add(this.xlblVisualStudio);
            this.Controls.Add(this.xlblQuestionOneTask);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "QuestionDragAndDropScreen";
            this.Text = "QuestionDragAndDrop";
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbVisualStudio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbSharepoint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbWindows)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox xpcbAvatar;
        private System.Windows.Forms.Label xlblScore;
        private System.Windows.Forms.PictureBox xpcbVisualStudio;
        private System.Windows.Forms.PictureBox xpcbSharepoint;
        private System.Windows.Forms.PictureBox xpcbWindows;
        private System.Windows.Forms.Label xlblSharepoint;
        private System.Windows.Forms.Label xlblWindows;
        private System.Windows.Forms.Label xlblVisualStudio;
        private System.Windows.Forms.Label xlblQuestionOneTask;
    }
}