﻿namespace Quiz5110
{
    partial class QuestionTickboxScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xbtnNext = new System.Windows.Forms.Button();
            this.xchkbxAnswer6 = new System.Windows.Forms.CheckBox();
            this.xchkbxAnswer4 = new System.Windows.Forms.CheckBox();
            this.xchkbxAnswer2 = new System.Windows.Forms.CheckBox();
            this.xchkbxAnswer5 = new System.Windows.Forms.CheckBox();
            this.xchkbxAnswer3 = new System.Windows.Forms.CheckBox();
            this.xchkbxAnswer1 = new System.Windows.Forms.CheckBox();
            this.xlblScore = new System.Windows.Forms.Label();
            this.xlblQuestionTwoText = new System.Windows.Forms.Label();
            this.xpctbxRightArrow = new System.Windows.Forms.PictureBox();
            this.xpcbAvatar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxRightArrow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).BeginInit();
            this.SuspendLayout();
            // 
            // xbtnNext
            // 
            this.xbtnNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnNext.Location = new System.Drawing.Point(240, 296);
            this.xbtnNext.Name = "xbtnNext";
            this.xbtnNext.Size = new System.Drawing.Size(158, 54);
            this.xbtnNext.TabIndex = 22;
            this.xbtnNext.Text = "Next";
            this.xbtnNext.UseVisualStyleBackColor = true;
            this.xbtnNext.Click += new System.EventHandler(this.xbtnNext_Click);
            // 
            // xchkbxAnswer6
            // 
            this.xchkbxAnswer6.AutoSize = true;
            this.xchkbxAnswer6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xchkbxAnswer6.Location = new System.Drawing.Point(334, 240);
            this.xchkbxAnswer6.Name = "xchkbxAnswer6";
            this.xchkbxAnswer6.Size = new System.Drawing.Size(67, 17);
            this.xchkbxAnswer6.TabIndex = 21;
            this.xchkbxAnswer6.Text = "Answer6";
            this.xchkbxAnswer6.UseVisualStyleBackColor = true;
            this.xchkbxAnswer6.CheckedChanged += new System.EventHandler(this.xAnswers_CheckedChanged);
            // 
            // xchkbxAnswer4
            // 
            this.xchkbxAnswer4.AutoSize = true;
            this.xchkbxAnswer4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xchkbxAnswer4.Location = new System.Drawing.Point(334, 191);
            this.xchkbxAnswer4.Name = "xchkbxAnswer4";
            this.xchkbxAnswer4.Size = new System.Drawing.Size(67, 17);
            this.xchkbxAnswer4.TabIndex = 20;
            this.xchkbxAnswer4.Text = "Answer4";
            this.xchkbxAnswer4.UseVisualStyleBackColor = true;
            this.xchkbxAnswer4.CheckedChanged += new System.EventHandler(this.xAnswers_CheckedChanged);
            // 
            // xchkbxAnswer2
            // 
            this.xchkbxAnswer2.AutoSize = true;
            this.xchkbxAnswer2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xchkbxAnswer2.Location = new System.Drawing.Point(334, 142);
            this.xchkbxAnswer2.Name = "xchkbxAnswer2";
            this.xchkbxAnswer2.Size = new System.Drawing.Size(67, 17);
            this.xchkbxAnswer2.TabIndex = 19;
            this.xchkbxAnswer2.Text = "Answer2";
            this.xchkbxAnswer2.UseVisualStyleBackColor = true;
            this.xchkbxAnswer2.CheckedChanged += new System.EventHandler(this.xAnswers_CheckedChanged);
            // 
            // xchkbxAnswer5
            // 
            this.xchkbxAnswer5.AutoSize = true;
            this.xchkbxAnswer5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xchkbxAnswer5.Location = new System.Drawing.Point(94, 240);
            this.xchkbxAnswer5.Name = "xchkbxAnswer5";
            this.xchkbxAnswer5.Size = new System.Drawing.Size(67, 17);
            this.xchkbxAnswer5.TabIndex = 18;
            this.xchkbxAnswer5.Text = "Answer5";
            this.xchkbxAnswer5.UseVisualStyleBackColor = true;
            this.xchkbxAnswer5.CheckedChanged += new System.EventHandler(this.xAnswers_CheckedChanged);
            // 
            // xchkbxAnswer3
            // 
            this.xchkbxAnswer3.AutoSize = true;
            this.xchkbxAnswer3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xchkbxAnswer3.Location = new System.Drawing.Point(94, 191);
            this.xchkbxAnswer3.Name = "xchkbxAnswer3";
            this.xchkbxAnswer3.Size = new System.Drawing.Size(67, 17);
            this.xchkbxAnswer3.TabIndex = 17;
            this.xchkbxAnswer3.Text = "Answer3";
            this.xchkbxAnswer3.UseVisualStyleBackColor = true;
            this.xchkbxAnswer3.CheckedChanged += new System.EventHandler(this.xAnswers_CheckedChanged);
            // 
            // xchkbxAnswer1
            // 
            this.xchkbxAnswer1.AutoSize = true;
            this.xchkbxAnswer1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xchkbxAnswer1.Location = new System.Drawing.Point(94, 142);
            this.xchkbxAnswer1.Name = "xchkbxAnswer1";
            this.xchkbxAnswer1.Size = new System.Drawing.Size(67, 17);
            this.xchkbxAnswer1.TabIndex = 16;
            this.xchkbxAnswer1.Text = "Answer1";
            this.xchkbxAnswer1.UseVisualStyleBackColor = true;
            this.xchkbxAnswer1.CheckedChanged += new System.EventHandler(this.xAnswers_CheckedChanged);
            // 
            // xlblScore
            // 
            this.xlblScore.AutoSize = true;
            this.xlblScore.Location = new System.Drawing.Point(12, 9);
            this.xlblScore.Name = "xlblScore";
            this.xlblScore.Size = new System.Drawing.Size(38, 13);
            this.xlblScore.TabIndex = 13;
            this.xlblScore.Text = "Score:";
            // 
            // xlblQuestionTwoText
            // 
            this.xlblQuestionTwoText.AutoSize = true;
            this.xlblQuestionTwoText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblQuestionTwoText.Location = new System.Drawing.Point(34, 56);
            this.xlblQuestionTwoText.Name = "xlblQuestionTwoText";
            this.xlblQuestionTwoText.Size = new System.Drawing.Size(103, 20);
            this.xlblQuestionTwoText.TabIndex = 14;
            this.xlblQuestionTwoText.Text = "QuestionText";
            // 
            // xpctbxRightArrow
            // 
            this.xpctbxRightArrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xpctbxRightArrow.Image = global::Quiz5110.Properties.Resources.RightArrow;
            this.xpctbxRightArrow.Location = new System.Drawing.Point(263, 279);
            this.xpctbxRightArrow.Name = "xpctbxRightArrow";
            this.xpctbxRightArrow.Size = new System.Drawing.Size(114, 89);
            this.xpctbxRightArrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpctbxRightArrow.TabIndex = 44;
            this.xpctbxRightArrow.TabStop = false;
            this.xpctbxRightArrow.Click += new System.EventHandler(this.xbtnNext_Click);
            this.xpctbxRightArrow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.xpctbxRightArrow_MouseDown);
            this.xpctbxRightArrow.MouseEnter += new System.EventHandler(this.xpctbxRightArrow_MouseEnter);
            this.xpctbxRightArrow.MouseLeave += new System.EventHandler(this.xpctbxRightArrow_MouseLeave);
            this.xpctbxRightArrow.MouseUp += new System.Windows.Forms.MouseEventHandler(this.xpctbxRightArrow_MouseUp);
            // 
            // xpcbAvatar
            // 
            this.xpcbAvatar.Location = new System.Drawing.Point(542, 12);
            this.xpcbAvatar.Name = "xpcbAvatar";
            this.xpcbAvatar.Size = new System.Drawing.Size(75, 75);
            this.xpcbAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpcbAvatar.TabIndex = 15;
            this.xpcbAvatar.TabStop = false;
            // 
            // QuestionTickboxScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.Controls.Add(this.xpctbxRightArrow);
            this.Controls.Add(this.xbtnNext);
            this.Controls.Add(this.xchkbxAnswer6);
            this.Controls.Add(this.xchkbxAnswer4);
            this.Controls.Add(this.xchkbxAnswer2);
            this.Controls.Add(this.xchkbxAnswer5);
            this.Controls.Add(this.xchkbxAnswer3);
            this.Controls.Add(this.xchkbxAnswer1);
            this.Controls.Add(this.xpcbAvatar);
            this.Controls.Add(this.xlblScore);
            this.Controls.Add(this.xlblQuestionTwoText);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "QuestionTickboxScreen";
            this.Text = "QuestionTickboxScreen";
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxRightArrow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button xbtnNext;
        private System.Windows.Forms.CheckBox xchkbxAnswer6;
        private System.Windows.Forms.CheckBox xchkbxAnswer4;
        private System.Windows.Forms.CheckBox xchkbxAnswer2;
        private System.Windows.Forms.CheckBox xchkbxAnswer5;
        private System.Windows.Forms.CheckBox xchkbxAnswer3;
        private System.Windows.Forms.CheckBox xchkbxAnswer1;
        private System.Windows.Forms.PictureBox xpcbAvatar;
        private System.Windows.Forms.Label xlblScore;
        private System.Windows.Forms.Label xlblQuestionTwoText;
        private System.Windows.Forms.PictureBox xpctbxRightArrow;
    }
}