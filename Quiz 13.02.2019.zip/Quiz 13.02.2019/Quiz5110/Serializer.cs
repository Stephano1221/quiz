﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Quiz5110
{
    public class Serializer
    {
        public static bool SerializePlayer(Player objectToSerialize)
        {
            try
            {
                Stream stream = File.Open($"SerializedPlayer.bin", FileMode.Create);
                BinaryFormatter bFormatter = new BinaryFormatter();
                bFormatter.Serialize(stream, objectToSerialize);
                stream.Close();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static Player DeserializePlayer()
        {
            try
            {
                Stream stream = File.Open($"SerializedPlayer.bin", FileMode.Open);
                BinaryFormatter bFormatter = new BinaryFormatter();
                Player objectDeserialized = (Player)bFormatter.Deserialize(stream);
                stream.Close();

                return objectDeserialized;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
