﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz5110
{
    public partial class HolderForm : Form
    {
        public static int QuizNumber = 0;
        public static int CurrentQuestionTypeNumber = 1;
        public static int TickBoxPosition;
        public static int RadioPosition;
        public static int DragAndDropPosition;
        public static string comingFrom;

        public HolderForm()
        {
            InitializeComponent();
        }

        private void xHolderForm_Load(object sender, EventArgs e)
        {
            IsMdiContainer = true;

            LoadingScreen loadingScreen = new LoadingScreen();
            loadingScreen.MdiParent = this;
            loadingScreen.Dock = DockStyle.Fill;
            loadingScreen.Show();

            //Debug debug = new Debug();
            //debug.Show();

            //ShowQuestions showQuestions = new ShowQuestions();
            //showQuestions.Show();
        }
    }
}
