﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Quiz5110
{
    public partial class LeaderboardScreen : Form
    {
        public LeaderboardScreen()
        {
            InitializeComponent();
            SetAvatar();
            xbtnBack.Hide();
            xpctbxUp.Hide();
            SortAndDisplayScores();
        }

        private int scoreSortState = 1;

        private void SetAvatar()
        {
            if (AvatarSelectScreen.avatarName == "xpcbAvatar1")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar1;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar2")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar2;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar3")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar3;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar4")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar4;
                xpcbAvatar.Refresh();
            }
        }

        private void xlblScore_Clicked(object sender, EventArgs e)
        {
            if (scoreSortState == 1)
            {
                scoreSortState = 2;
            }
            else
            {
                scoreSortState = 1;
            }
            SortAndDisplayScores();
        }

        private void xlblDate_Clicked(object sender, EventArgs e)
        {
            if (scoreSortState == 3)
            {
                scoreSortState = 4;
            }
            else
            {
                scoreSortState = 3;
            }
            SortAndDisplayScores();
        }

        private void SortAndDisplayScores()
        {
            xlstbxLeaderboard.Items.Clear();
            string filePath = "previousscores.txt";
            if (File.Exists(filePath))
            {
                FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                StreamReader sr = new StreamReader(fs);
                int numLinesInFile = File.ReadLines(filePath).Count();
                string[,] readScores = new string[numLinesInFile, 4];
                string[,] highLowScores = new string[numLinesInFile, 4];

                while (sr.Peek() >= 0)
                {

                    for (int i = 0; i < numLinesInFile; i++)
                    {
                        string readLine = sr.ReadLine();
                        string[] scoreElements = readLine.Split('~'); //readLine.Split(separators, StringSplitOptions.None);

                        for (int a = 0; a < scoreElements.Length; a++)
                        {
                            readScores[i, a] = scoreElements[a];
                            highLowScores[i, a] = readScores[i, a];
                        }

                        readScores[i, 3] = Convert.ToString(Math.Round((Convert.ToDouble(readScores[i, 1]) / Convert.ToDouble(readScores[i, 2])), 2) * 100);
                        highLowScores[i, 3] = readScores[i, 3];

                        int b = i;
                        double leftPer = Convert.ToDouble(highLowScores[b, 3]);
                        if (b > 0)
                        {
                            leftPer = Convert.ToDouble(highLowScores[b - 1, 3]);
                        }

                        while (Convert.ToDouble(highLowScores[b, 3]) > leftPer && b < highLowScores.GetLength(0) && b > 0)
                        {
                            string[] currentData = new string[4];
                            string[] previousData = new string[4];
                            for (int c = 0; c < highLowScores.GetLength(1); c++)
                            {
                                currentData[c] = highLowScores[b, c];
                                previousData[c] = highLowScores[b - 1, c];
                                highLowScores[b, c] = previousData[c];
                                highLowScores[b - 1, c] = currentData[c];
                            }
                            b--;
                            if (b > 0)
                            {
                                leftPer = Convert.ToDouble(highLowScores[b - 1, 3]);
                            }
                        }
                    }
                    if (scoreSortState == 1)
                    {
                        xpctbxUp.Hide();
                        xpctbxDown.Show();
                        xpctbxDown.Left = 126;
                        xpctbxDown.Top = 100;
                        for (int d = 0; d < highLowScores.GetLength(0); d++)
                        {
                            xlstbxLeaderboard.Items.Add($"{highLowScores[d, 0]} scored {highLowScores[d, 1]} out of {highLowScores[d, 2]} points ({highLowScores[d, 3]}%)");
                        }
                    }
                    else if (scoreSortState == 2)
                    {
                        xpctbxDown.Hide();
                        xpctbxUp.Show();
                        xpctbxUp.Left = 126;
                        xpctbxUp.Top = 100;
                        string[,] highLowScoresReversed = ReverseMultiDArray(highLowScores);
                        for (int d = 0; d < highLowScoresReversed.GetLength(0); d++)
                        {
                            xlstbxLeaderboard.Items.Add($"{highLowScoresReversed[d, 0]} scored {highLowScoresReversed[d, 1]} out of {highLowScoresReversed[d, 2]} points ({highLowScoresReversed[d, 3]}%)");
                        }
                    }
                    else if (scoreSortState == 3)
                    {
                        xpctbxUp.Hide();
                        xpctbxDown.Show();
                        xpctbxDown.Left = 164;
                        xpctbxDown.Top = 100;
                        string[,] readScoresReversed = ReverseMultiDArray(readScores);
                        for (int d = 0; d < readScoresReversed.GetLength(0); d++)
                        {
                            xlstbxLeaderboard.Items.Add($"{readScoresReversed[d, 0]} scored {readScoresReversed[d, 1]} out of {readScoresReversed[d, 2]} points ({readScoresReversed[d, 3]}%)");
                        }
                    }
                    else if (scoreSortState == 4)
                    {
                        xpctbxDown.Hide();
                        xpctbxUp.Show();
                        xpctbxUp.Left = 164;
                        xpctbxUp.Top = 100;
                        for (int d = 0; d < readScores.GetLength(0); d++)
                        {
                            xlstbxLeaderboard.Items.Add($"{readScores[d, 0]} scored {readScores[d, 1]} out of {readScores[d, 2]} points ({readScores[d, 3]}%)");
                        }
                    }
                }
                sr.Close();
            }
            else
            {
                xlstbxLeaderboard.DataSource = new List<string> { "No previous players details have been found" };
            }
        }

        private string[,] ReverseMultiDArray(string[,] array)
        {
            string[,] reversedArray = DeepClone(array);
            for (int i = 0; i < array.GetLength(0); i++)
            {
                string[] left = new string[4];
                //string[] right = new string[4];
                for (int b = 0; b < array.GetLength(1); b++)
                {
                    left[b] = array[i, b];
                    //right[b] = array[array.GetUpperBound(0) - i, b];
                    //reversedArray[i, b] = right[b];
                    reversedArray[reversedArray.GetUpperBound(0) - i, b] = left[b];
                }
            }
            return reversedArray;
        }

        public static T DeepClone<T>(T obj)
        {
            MemoryStream ms = new MemoryStream();
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ms, obj);
            ms.Position = 0;
            return (T)bf.Deserialize(ms);
        }

        private void xbtnBack_Click(object sender, EventArgs e)
        {
            if (HolderForm.comingFrom == "EndScreen")
            {
                EndScreen endScreen = new EndScreen(false); //EndScreen();
                endScreen.MdiParent = this.ParentForm;
                endScreen.Dock = DockStyle.Fill;
                endScreen.Show();
                this.Close();
            }
            else if (HolderForm.comingFrom == "MenuScreen")
            {
                MenuScreen menuScreen = new MenuScreen(MenuScreen.Player.username);
                menuScreen.MdiParent = this.ParentForm;
                menuScreen.Dock = DockStyle.Fill;
                menuScreen.Show();
                this.Close();
            }
        }

        private void xKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return || e.KeyChar == (char)Keys.Escape)
            {
                xbtnBack_Click(sender, e);
            }
        }

        private void xpctbxLeftArrow_MouseEnter(object sender, EventArgs e)
        {
            xpctbxLeftArrow.Image = Properties.Resources.LeftArrowHover;
        }

        private void xpctbxLeftArrow_MouseLeave(object sender, EventArgs e)
        {
            xpctbxLeftArrow.Image = Properties.Resources.LeftArrow;
        }

        private void xpctbxLeftArrow_MouseDown(object sender, MouseEventArgs e)
        {
            xpctbxLeftArrow.Image = Properties.Resources.LeftArrowClick;
        }

        private void xpctbxLeftArrow_MouseUp(object sender, MouseEventArgs e)
        {
            xpctbxLeftArrow.Image = Properties.Resources.LeftArrow;
        }
    }
}