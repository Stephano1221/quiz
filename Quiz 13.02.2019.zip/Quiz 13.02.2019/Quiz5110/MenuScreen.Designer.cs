﻿namespace Quiz5110
{
    partial class MenuScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuScreen));
            this.xlblLastScore = new System.Windows.Forms.Label();
            this.xbtnComputerHardware = new System.Windows.Forms.Button();
            this.xbtnWirelessTechnologies = new System.Windows.Forms.Button();
            this.xlblWelcome = new System.Windows.Forms.Label();
            this.xlblCreator = new System.Windows.Forms.Label();
            this.xbtnNetworks = new System.Windows.Forms.Button();
            this.xlblQuizTitle = new System.Windows.Forms.Label();
            this.xmsMenu = new System.Windows.Forms.MenuStrip();
            this.xtsmiMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.xpcbAvatar = new System.Windows.Forms.PictureBox();
            this.xmsMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).BeginInit();
            this.SuspendLayout();
            // 
            // xlblLastScore
            // 
            this.xlblLastScore.AutoSize = true;
            this.xlblLastScore.Location = new System.Drawing.Point(12, 415);
            this.xlblLastScore.Name = "xlblLastScore";
            this.xlblLastScore.Size = new System.Drawing.Size(244, 26);
            this.xlblLastScore.TabIndex = 8;
            this.xlblLastScore.Text = "Last Score:\r\n[Username] scored [Score] out of [MaximumScore]";
            // 
            // xbtnComputerHardware
            // 
            this.xbtnComputerHardware.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnComputerHardware.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnComputerHardware.Location = new System.Drawing.Point(216, 330);
            this.xbtnComputerHardware.Name = "xbtnComputerHardware";
            this.xbtnComputerHardware.Size = new System.Drawing.Size(200, 75);
            this.xbtnComputerHardware.TabIndex = 14;
            this.xbtnComputerHardware.Text = "Computer Hardware";
            this.xbtnComputerHardware.UseVisualStyleBackColor = true;
            this.xbtnComputerHardware.Click += new System.EventHandler(this.xbtnComputerHardware_Click);
            // 
            // xbtnWirelessTechnologies
            // 
            this.xbtnWirelessTechnologies.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnWirelessTechnologies.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnWirelessTechnologies.Location = new System.Drawing.Point(329, 239);
            this.xbtnWirelessTechnologies.Name = "xbtnWirelessTechnologies";
            this.xbtnWirelessTechnologies.Size = new System.Drawing.Size(200, 75);
            this.xbtnWirelessTechnologies.TabIndex = 13;
            this.xbtnWirelessTechnologies.Text = "Wireless Technologies";
            this.xbtnWirelessTechnologies.UseVisualStyleBackColor = true;
            this.xbtnWirelessTechnologies.Click += new System.EventHandler(this.xbtnWirelessTechnologies_Click);
            // 
            // xlblWelcome
            // 
            this.xlblWelcome.AutoSize = true;
            this.xlblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblWelcome.Location = new System.Drawing.Point(182, 193);
            this.xlblWelcome.Name = "xlblWelcome";
            this.xlblWelcome.Size = new System.Drawing.Size(251, 20);
            this.xlblWelcome.TabIndex = 9;
            this.xlblWelcome.Text = "Welcome, [Username], to the quiz!";
            // 
            // xlblCreator
            // 
            this.xlblCreator.AutoSize = true;
            this.xlblCreator.Location = new System.Drawing.Point(426, 151);
            this.xlblCreator.Name = "xlblCreator";
            this.xlblCreator.Size = new System.Drawing.Size(81, 13);
            this.xlblCreator.TabIndex = 10;
            this.xlblCreator.Text = "By Nathan Cole";
            // 
            // xbtnNetworks
            // 
            this.xbtnNetworks.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnNetworks.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnNetworks.Location = new System.Drawing.Point(97, 239);
            this.xbtnNetworks.Name = "xbtnNetworks";
            this.xbtnNetworks.Size = new System.Drawing.Size(200, 75);
            this.xbtnNetworks.TabIndex = 12;
            this.xbtnNetworks.Text = "Networks";
            this.xbtnNetworks.UseVisualStyleBackColor = true;
            this.xbtnNetworks.Click += new System.EventHandler(this.xbtnNetworks_Click);
            // 
            // xlblQuizTitle
            // 
            this.xlblQuizTitle.AutoSize = true;
            this.xlblQuizTitle.Font = new System.Drawing.Font("Showcard Gothic", 72F, System.Drawing.FontStyle.Bold);
            this.xlblQuizTitle.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.xlblQuizTitle.Location = new System.Drawing.Point(86, 32);
            this.xlblQuizTitle.Name = "xlblQuizTitle";
            this.xlblQuizTitle.Size = new System.Drawing.Size(457, 119);
            this.xlblQuizTitle.TabIndex = 11;
            this.xlblQuizTitle.Text = "ICT Quiz";
            // 
            // xmsMenu
            // 
            this.xmsMenu.BackColor = System.Drawing.SystemColors.Menu;
            this.xmsMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xtsmiMenu});
            this.xmsMenu.Location = new System.Drawing.Point(0, 0);
            this.xmsMenu.Name = "xmsMenu";
            this.xmsMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.xmsMenu.Size = new System.Drawing.Size(640, 24);
            this.xmsMenu.TabIndex = 16;
            this.xmsMenu.Text = "Menu";
            // 
            // xtsmiMenu
            // 
            this.xtsmiMenu.Name = "xtsmiMenu";
            this.xtsmiMenu.Size = new System.Drawing.Size(45, 20);
            this.xtsmiMenu.Text = "Menu";
            this.xtsmiMenu.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.xMenuDropDownItem_Click);
            this.xtsmiMenu.MouseEnter += new System.EventHandler(this.xMouseEnter);
            this.xtsmiMenu.MouseLeave += new System.EventHandler(this.xMouseLeave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(161, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(312, 124);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // xpcbAvatar
            // 
            this.xpcbAvatar.Location = new System.Drawing.Point(542, 12);
            this.xpcbAvatar.Name = "xpcbAvatar";
            this.xpcbAvatar.Size = new System.Drawing.Size(75, 75);
            this.xpcbAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpcbAvatar.TabIndex = 15;
            this.xpcbAvatar.TabStop = false;
            // 
            // MenuScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.xpcbAvatar);
            this.Controls.Add(this.xlblLastScore);
            this.Controls.Add(this.xbtnComputerHardware);
            this.Controls.Add(this.xbtnWirelessTechnologies);
            this.Controls.Add(this.xlblWelcome);
            this.Controls.Add(this.xlblCreator);
            this.Controls.Add(this.xbtnNetworks);
            this.Controls.Add(this.xlblQuizTitle);
            this.Controls.Add(this.xmsMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MenuScreen";
            this.Text = "MenuScreen";
            this.xmsMenu.ResumeLayout(false);
            this.xmsMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox xpcbAvatar;
        private System.Windows.Forms.Label xlblLastScore;
        private System.Windows.Forms.Button xbtnComputerHardware;
        private System.Windows.Forms.Button xbtnWirelessTechnologies;
        private System.Windows.Forms.Label xlblWelcome;
        private System.Windows.Forms.Label xlblCreator;
        private System.Windows.Forms.Button xbtnNetworks;
        private System.Windows.Forms.Label xlblQuizTitle;
        private System.Windows.Forms.MenuStrip xmsMenu;
        private System.Windows.Forms.ToolStripMenuItem xtsmiMenu;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}