﻿namespace Quiz5110
{
    partial class RegisterScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xbtnBack = new System.Windows.Forms.Button();
            this.xbtnRegister = new System.Windows.Forms.Button();
            this.xtxtbxPassword = new System.Windows.Forms.TextBox();
            this.xlblPassword = new System.Windows.Forms.Label();
            this.xtxtbxUsername = new System.Windows.Forms.TextBox();
            this.xlblUsername = new System.Windows.Forms.Label();
            this.xlblRegister = new System.Windows.Forms.Label();
            this.xlblPassReq1 = new System.Windows.Forms.Label();
            this.xlblPassReq2 = new System.Windows.Forms.Label();
            this.xlblPassReq3 = new System.Windows.Forms.Label();
            this.xtxtbxConfirmPassword = new System.Windows.Forms.TextBox();
            this.xlblConfirmPassword = new System.Windows.Forms.Label();
            this.xlblPassReq4 = new System.Windows.Forms.Label();
            this.xpctbxLeftArrow = new System.Windows.Forms.PictureBox();
            this.xpctbxRightArrow = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxLeftArrow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxRightArrow)).BeginInit();
            this.SuspendLayout();
            // 
            // xbtnBack
            // 
            this.xbtnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.xbtnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnBack.Location = new System.Drawing.Point(39, 402);
            this.xbtnBack.Name = "xbtnBack";
            this.xbtnBack.Size = new System.Drawing.Size(80, 30);
            this.xbtnBack.TabIndex = 5;
            this.xbtnBack.Text = "Back";
            this.xbtnBack.UseVisualStyleBackColor = true;
            this.xbtnBack.Click += new System.EventHandler(this.xbtnBack_Click);
            // 
            // xbtnRegister
            // 
            this.xbtnRegister.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnRegister.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnRegister.Location = new System.Drawing.Point(280, 300);
            this.xbtnRegister.Name = "xbtnRegister";
            this.xbtnRegister.Size = new System.Drawing.Size(80, 30);
            this.xbtnRegister.TabIndex = 4;
            this.xbtnRegister.Text = "Register";
            this.xbtnRegister.UseVisualStyleBackColor = true;
            this.xbtnRegister.Click += new System.EventHandler(this.xpctbxRightArrow_Click);
            // 
            // xtxtbxPassword
            // 
            this.xtxtbxPassword.Location = new System.Drawing.Point(248, 225);
            this.xtxtbxPassword.MaxLength = 18;
            this.xtxtbxPassword.Name = "xtxtbxPassword";
            this.xtxtbxPassword.Size = new System.Drawing.Size(143, 20);
            this.xtxtbxPassword.TabIndex = 2;
            this.xtxtbxPassword.UseSystemPasswordChar = true;
            this.xtxtbxPassword.TextChanged += new System.EventHandler(this.xPassword_TextChanged);
            this.xtxtbxPassword.Enter += new System.EventHandler(this.xPassword_Enter);
            this.xtxtbxPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xKeyPress);
            // 
            // xlblPassword
            // 
            this.xlblPassword.AutoSize = true;
            this.xlblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblPassword.Location = new System.Drawing.Point(245, 206);
            this.xlblPassword.Name = "xlblPassword";
            this.xlblPassword.Size = new System.Drawing.Size(68, 16);
            this.xlblPassword.TabIndex = 0;
            this.xlblPassword.Text = "Password";
            // 
            // xtxtbxUsername
            // 
            this.xtxtbxUsername.Location = new System.Drawing.Point(248, 159);
            this.xtxtbxUsername.Name = "xtxtbxUsername";
            this.xtxtbxUsername.Size = new System.Drawing.Size(143, 20);
            this.xtxtbxUsername.TabIndex = 1;
            this.xtxtbxUsername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xKeyPress);
            // 
            // xlblUsername
            // 
            this.xlblUsername.AutoSize = true;
            this.xlblUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblUsername.Location = new System.Drawing.Point(245, 140);
            this.xlblUsername.Name = "xlblUsername";
            this.xlblUsername.Size = new System.Drawing.Size(71, 16);
            this.xlblUsername.TabIndex = 0;
            this.xlblUsername.Text = "Username";
            // 
            // xlblRegister
            // 
            this.xlblRegister.AutoSize = true;
            this.xlblRegister.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblRegister.Location = new System.Drawing.Point(250, 80);
            this.xlblRegister.Name = "xlblRegister";
            this.xlblRegister.Size = new System.Drawing.Size(134, 37);
            this.xlblRegister.TabIndex = 0;
            this.xlblRegister.Text = "Register";
            // 
            // xlblPassReq1
            // 
            this.xlblPassReq1.AutoSize = true;
            this.xlblPassReq1.ForeColor = System.Drawing.Color.Red;
            this.xlblPassReq1.Location = new System.Drawing.Point(201, 363);
            this.xlblPassReq1.Name = "xlblPassReq1";
            this.xlblPassReq1.Size = new System.Drawing.Size(242, 13);
            this.xlblPassReq1.TabIndex = 0;
            this.xlblPassReq1.Text = "The password must contain at least six characters";
            this.xlblPassReq1.Visible = false;
            // 
            // xlblPassReq2
            // 
            this.xlblPassReq2.AutoSize = true;
            this.xlblPassReq2.ForeColor = System.Drawing.Color.Red;
            this.xlblPassReq2.Location = new System.Drawing.Point(201, 376);
            this.xlblPassReq2.Name = "xlblPassReq2";
            this.xlblPassReq2.Size = new System.Drawing.Size(221, 13);
            this.xlblPassReq2.TabIndex = 0;
            this.xlblPassReq2.Text = "The password must contain at least one letter";
            this.xlblPassReq2.Visible = false;
            // 
            // xlblPassReq3
            // 
            this.xlblPassReq3.AutoSize = true;
            this.xlblPassReq3.ForeColor = System.Drawing.Color.Red;
            this.xlblPassReq3.Location = new System.Drawing.Point(201, 389);
            this.xlblPassReq3.Name = "xlblPassReq3";
            this.xlblPassReq3.Size = new System.Drawing.Size(233, 13);
            this.xlblPassReq3.TabIndex = 0;
            this.xlblPassReq3.Text = "The password must contain at least one number";
            this.xlblPassReq3.Visible = false;
            // 
            // xtxtbxConfirmPassword
            // 
            this.xtxtbxConfirmPassword.Location = new System.Drawing.Point(248, 267);
            this.xtxtbxConfirmPassword.MaxLength = 18;
            this.xtxtbxConfirmPassword.Name = "xtxtbxConfirmPassword";
            this.xtxtbxConfirmPassword.Size = new System.Drawing.Size(143, 20);
            this.xtxtbxConfirmPassword.TabIndex = 3;
            this.xtxtbxConfirmPassword.UseSystemPasswordChar = true;
            this.xtxtbxConfirmPassword.TextChanged += new System.EventHandler(this.xPassword_TextChanged);
            this.xtxtbxConfirmPassword.Enter += new System.EventHandler(this.xPassword_Enter);
            this.xtxtbxConfirmPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xKeyPress);
            // 
            // xlblConfirmPassword
            // 
            this.xlblConfirmPassword.AutoSize = true;
            this.xlblConfirmPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblConfirmPassword.Location = new System.Drawing.Point(245, 248);
            this.xlblConfirmPassword.Name = "xlblConfirmPassword";
            this.xlblConfirmPassword.Size = new System.Drawing.Size(116, 16);
            this.xlblConfirmPassword.TabIndex = 0;
            this.xlblConfirmPassword.Text = "Confirm Password";
            // 
            // xlblPassReq4
            // 
            this.xlblPassReq4.AutoSize = true;
            this.xlblPassReq4.ForeColor = System.Drawing.Color.Red;
            this.xlblPassReq4.Location = new System.Drawing.Point(201, 402);
            this.xlblPassReq4.Name = "xlblPassReq4";
            this.xlblPassReq4.Size = new System.Drawing.Size(136, 13);
            this.xlblPassReq4.TabIndex = 6;
            this.xlblPassReq4.Text = "The passwords must match";
            this.xlblPassReq4.Visible = false;
            // 
            // xpctbxLeftArrow
            // 
            this.xpctbxLeftArrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xpctbxLeftArrow.Image = global::Quiz5110.Properties.Resources.LeftArrow;
            this.xpctbxLeftArrow.Location = new System.Drawing.Point(12, 387);
            this.xpctbxLeftArrow.Name = "xpctbxLeftArrow";
            this.xpctbxLeftArrow.Size = new System.Drawing.Size(56, 45);
            this.xpctbxLeftArrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpctbxLeftArrow.TabIndex = 19;
            this.xpctbxLeftArrow.TabStop = false;
            this.xpctbxLeftArrow.Click += new System.EventHandler(this.xbtnBack_Click);
            this.xpctbxLeftArrow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.xpctbxLeftArrow_MouseDown);
            this.xpctbxLeftArrow.MouseEnter += new System.EventHandler(this.xpctbxLeftArrow_MouseEnter);
            this.xpctbxLeftArrow.MouseLeave += new System.EventHandler(this.xpctbxLeftArrow_MouseLeave);
            this.xpctbxLeftArrow.MouseUp += new System.Windows.Forms.MouseEventHandler(this.xpctbxLeftArrow_MouseUp);
            // 
            // xpctbxRightArrow
            // 
            this.xpctbxRightArrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xpctbxRightArrow.Image = global::Quiz5110.Properties.Resources.RightArrow;
            this.xpctbxRightArrow.Location = new System.Drawing.Point(292, 292);
            this.xpctbxRightArrow.Name = "xpctbxRightArrow";
            this.xpctbxRightArrow.Size = new System.Drawing.Size(56, 45);
            this.xpctbxRightArrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpctbxRightArrow.TabIndex = 18;
            this.xpctbxRightArrow.TabStop = false;
            this.xpctbxRightArrow.Click += new System.EventHandler(this.xpctbxRightArrow_Click);
            this.xpctbxRightArrow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.xpctbxRightArrow_MouseDown);
            this.xpctbxRightArrow.MouseEnter += new System.EventHandler(this.xpctbxRightArrow_MouseEnter);
            this.xpctbxRightArrow.MouseLeave += new System.EventHandler(this.xpctbxRightArrow_MouseLeave);
            this.xpctbxRightArrow.MouseUp += new System.Windows.Forms.MouseEventHandler(this.xpctbxRightArrow_MouseUp);
            // 
            // RegisterScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.Controls.Add(this.xpctbxLeftArrow);
            this.Controls.Add(this.xpctbxRightArrow);
            this.Controls.Add(this.xlblPassReq4);
            this.Controls.Add(this.xtxtbxConfirmPassword);
            this.Controls.Add(this.xlblConfirmPassword);
            this.Controls.Add(this.xlblPassReq3);
            this.Controls.Add(this.xlblPassReq2);
            this.Controls.Add(this.xlblPassReq1);
            this.Controls.Add(this.xbtnBack);
            this.Controls.Add(this.xbtnRegister);
            this.Controls.Add(this.xtxtbxPassword);
            this.Controls.Add(this.xlblPassword);
            this.Controls.Add(this.xtxtbxUsername);
            this.Controls.Add(this.xlblUsername);
            this.Controls.Add(this.xlblRegister);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RegisterScreen";
            this.Text = "RegisterScreen";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xKeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxLeftArrow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxRightArrow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button xbtnBack;
        private System.Windows.Forms.Button xbtnRegister;
        private System.Windows.Forms.TextBox xtxtbxPassword;
        private System.Windows.Forms.Label xlblPassword;
        private System.Windows.Forms.TextBox xtxtbxUsername;
        private System.Windows.Forms.Label xlblUsername;
        private System.Windows.Forms.Label xlblRegister;
        private System.Windows.Forms.Label xlblPassReq1;
        private System.Windows.Forms.Label xlblPassReq2;
        private System.Windows.Forms.Label xlblPassReq3;
        private System.Windows.Forms.TextBox xtxtbxConfirmPassword;
        private System.Windows.Forms.Label xlblConfirmPassword;
        private System.Windows.Forms.Label xlblPassReq4;
        private System.Windows.Forms.PictureBox xpctbxRightArrow;
        private System.Windows.Forms.PictureBox xpctbxLeftArrow;
    }
}