﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Quiz5110
{
    public partial class RegisterScreen : Form
    {
        private static string username1;

        public RegisterScreen(string username)
        {
            InitializeComponent();
            username1 = username;
            xbtnRegister.Hide();
            xbtnBack.Hide();
        }

        private void xPassword_Enter(object sender, EventArgs e)
        {
            xlblPassReq1.Visible = true;
            xlblPassReq2.Visible = true;
            xlblPassReq3.Visible = true;
            xlblPassReq4.Visible = true;
        }

        private void xpctbxRightArrow_Click(object sender, EventArgs e)
        {
            string username = xtxtbxUsername.Text;
            string password = xtxtbxPassword.Text;
            string confirmPassword = xtxtbxConfirmPassword.Text;
            string filePath = "users.txt";

            if (CheckUsernamePassword(username, password, confirmPassword) == false)
            {
                return;
            }

            DialogResult dialogResult = MessageBox.Show($"You will only be able to register once if you aren't logged into a teacher account to prevent students from registering as a teacher.\nIf you forget your password, open the '{filePath}' file in the installation directory to recover your password.\nAlternatively, delete/rename the '{filePath}' file and attempt to register again.", "Warning", MessageBoxButtons.OKCancel);

            if (dialogResult == DialogResult.OK)
            {
                FileStream fs = null; //FileStream aFile;

                try
                {
                    fs = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Read);
                }
                catch (Exception) //(Exception ex)
                {
                    MessageBox.Show($"Failed to register. Please make sure that the {filePath} file is not in use.", "Error");
                    return;
                }

                using (StreamReader sr = new StreamReader(fs))
                {
                    while (sr.Peek() >= 0)
                    {
                        string readLine = sr.ReadLine();
                        string[] readElements = readLine.Split('~');
                        if (username == readElements[0])
                        {
                            MessageBox.Show($"An account with that username already exists.", "Error");
                            return;
                        }
                    }
                }
                fs.Close();
                try
                {
                    fs = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                    StreamWriter sw = new StreamWriter(fs);
                    sw.WriteLine($"{username}~{password}");
                    sw.Close();
                    fs.Close();
                }
                catch (Exception)
                {
                    MessageBox.Show($"Failed to register. Please make sure that the {filePath} file is not in use.", "Error");
                    return;
                }

                xtxtbxUsername.Text = "";
                xtxtbxPassword.Text = "";

                if (LoginScreen.userFound == false)
                {
                    LoginScreen loginScreen = new LoginScreen();
                    loginScreen.MdiParent = this.ParentForm;
                    loginScreen.Dock = DockStyle.Fill;
                    loginScreen.Show();
                    this.Close();
                }
                if (LoginScreen.userFound == true)
                {
                    MenuScreen menuScreen = new MenuScreen(username1);
                    menuScreen.MdiParent = this.ParentForm;
                    menuScreen.Dock = DockStyle.Fill;
                    menuScreen.Show();
                    this.Close();
                }

                MessageBox.Show($"Account created successfully.", "Registered");
            }
        }

        private bool CheckUsernamePassword(string username, string password, string confirmPassword)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword))
            {
                MessageBox.Show($"All fields are required.", "Error");
                return false;
            }
            if (username.Contains("~") && !password.Contains("~"))
            {
                MessageBox.Show($"Invalid character (~) in the username field.", "Error");
                return false;
            }
            if (!username.Contains("~") && password.Contains("~"))
            {
                MessageBox.Show($"Invalid character (~) in the password field.", "Error");
                return false;
            }
            if (username.Contains("~") && password.Contains("~"))
            {
                MessageBox.Show($"Invalid character (~) in the username and password fields.", "Error");
                return false;
            }
            if (password.Length < 6)
            {
                MessageBox.Show($"The password must be at least six characters.", "Error");
                return false;
            }
            if (!password.Any((char.IsLetter)))
            {
                MessageBox.Show($"The password must contain at least one letter.", "Error");
                return false;
            }
            if (!password.Any((char.IsDigit)))
            {
                MessageBox.Show($"The password must contain at least one number.", "Error");
                return false;
            }
            if (!(password == confirmPassword))
            {
                MessageBox.Show($"The passwords must match.", "Error");
                return false;
            }
            else
            {
                return true;
            }
        }

        private void xPassword_TextChanged(object sender, EventArgs e)
        {
            string password = xtxtbxPassword.Text;
            string confirmPassword = xtxtbxConfirmPassword.Text;
            if (password.Length < 6)
            {
                xlblPassReq1.ForeColor = Color.Red;
            }
            else
            {
                xlblPassReq1.ForeColor = Color.Green;
            }
            if (!password.Any((char.IsLetter)))
            {
                xlblPassReq2.ForeColor = Color.Red;
            }
            else
            {
                xlblPassReq2.ForeColor = Color.Green;
            }
            if (!password.Any((char.IsDigit)))
            {
                xlblPassReq3.ForeColor = Color.Red;
            }
            else
            {
                xlblPassReq3.ForeColor = Color.Green;
            }
            if (!(password == confirmPassword))
            {
                xlblPassReq4.ForeColor = Color.Red;
            }
            else
            {
                xlblPassReq4.ForeColor = Color.Green;
            }
        }

        private void xbtnBack_Click(object sender, EventArgs e)
        {
            if (HolderForm.comingFrom == "LoginScreen")
            {
                LoginScreen loginScreen = new LoginScreen();
                loginScreen.MdiParent = this.ParentForm;
                loginScreen.Dock = DockStyle.Fill;
                loginScreen.Show();
                this.Close();
            }
            else if (HolderForm.comingFrom == "MenuScreen")
            {
                MenuScreen menuScreen = new MenuScreen(username1);
                menuScreen.MdiParent = this.ParentForm;
                menuScreen.Dock = DockStyle.Fill;
                menuScreen.Show();
                this.Close();
            }

        }

        private void xKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                xpctbxRightArrow_Click(sender, e);
            }
            if (e.KeyChar == (char)Keys.Escape)
            {
                xbtnBack_Click(sender, e);
            }
        }

        private void xpctbxRightArrow_MouseEnter(object sender, EventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrowHover;
        }

        private void xpctbxRightArrow_MouseLeave(object sender, EventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrow;
        }

        private void xpctbxRightArrow_MouseDown(object sender, MouseEventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrowClick;
        }

        private void xpctbxRightArrow_MouseUp(object sender, MouseEventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrow;
        }

        private void xpctbxLeftArrow_MouseEnter(object sender, EventArgs e)
        {
            xpctbxLeftArrow.Image = Properties.Resources.LeftArrowHover;
        }

        private void xpctbxLeftArrow_MouseLeave(object sender, EventArgs e)
        {
            xpctbxLeftArrow.Image = Properties.Resources.LeftArrow;
        }

        private void xpctbxLeftArrow_MouseDown(object sender, MouseEventArgs e)
        {
            xpctbxLeftArrow.Image = Properties.Resources.LeftArrowClick;
        }

        private void xpctbxLeftArrow_MouseUp(object sender, MouseEventArgs e)
        {
            xpctbxLeftArrow.Image = Properties.Resources.LeftArrow;
        }
    }
}
