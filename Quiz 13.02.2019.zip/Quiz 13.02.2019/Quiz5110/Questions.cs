﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.IO;

namespace Quiz5110
{
    class Questions
    {
        public string[,] quiz1QuestionsPublic;
        public string[,] quiz2QuestionsPublic;
        public string[,] quiz3QuestionsPublic;

        public void Main()
        {
            ReadQuestions();
        }

        private void ReadQuestions()
        {
            if (File.Exists($"/bin/quiz1questions.txt")) //Todo: Error if one of the quizes is not found
            {
                StreamReader sr = new StreamReader("/bin/quiz1questions.txt"); //Todo: Use bin directory
                int quiz1Count = File.ReadLines("/bin/quiz1questions.txt").Count();
                int quiz2Count = File.ReadLines("quiz2questions.txt").Count();
                int quiz3Count = File.ReadLines("quiz3questions.txt").Count();
                int currentQuizCount = 0;
                string[,] quiz1Questions = new string[quiz1Count, 14];
                string[,] quiz2Questions = new string[quiz2Count, 14];
                string[,] quiz3Questions = new string[quiz3Count, 14];

                while (sr.Peek() >= 0)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        if (i == 0)
                        {
                            currentQuizCount = quiz1Count;
                        }
                        else if (i == 1)
                        {
                            currentQuizCount = quiz2Count;
                            sr.Close();
                            sr = new StreamReader("quiz2questions.txt");
                        }
                        else if (i == 2)
                        {
                            currentQuizCount = quiz3Count;
                            sr.Close();
                            sr = new StreamReader("quiz3questions.txt");
                        }

                        for (int b = 0; b < currentQuizCount; b++)
                        {
                            string readLine = sr.ReadLine();
                            if (readLine.StartsWith("[Tickbox]") || readLine.StartsWith("[Radio]"))
                            {
                                //readLine = readLine.Substring(9).TrimStart();
                                string[] questionElements = readLine.Split('~');
                                if (i == 0)
                                {
                                    for (int c = 0; c < questionElements.Count(); c++)
                                    {
                                        quiz1Questions[b, c] = questionElements[c];
                                    }
                                }
                            }
                        }
                    }
                    quiz1QuestionsPublic = quiz1Questions;
                }
            }
        }
    }
}