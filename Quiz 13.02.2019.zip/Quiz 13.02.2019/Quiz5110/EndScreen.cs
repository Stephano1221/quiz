﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Quiz5110
{
    public partial class EndScreen : Form
    {
        public EndScreen(bool saveFiles)
        {
            InitializeComponent();
            SetTransparentLabels();
            SetAvatar();
            ShowHidePreviousScore();
            SaveDetails(saveFiles);
            xlblFinishing.Text = ($"{MenuScreen.Player.username}, you finished the quiz!");
            xlblScoreText.Text = ($"You scored {MenuScreen.Player.score} out of {QuestionTickboxScreen.TickBoxQuestionCount + QuestionRadioButtonScreen.RadioQuestionCount + QuestionDragAndDropScreen.dragAndDropQuestionCount} points");
            HolderForm.comingFrom = "EndScreen";
        }


        private void SetAvatar()
        {
            if (AvatarSelectScreen.avatarName == "xpcbAvatar1")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar1;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar2")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar2;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar3")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar3;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar4")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar4;
                xpcbAvatar.Refresh();
            }
        }

        private void SetTransparentLabels()
        {
            xpcbAvatar.Parent = xpctbxBackground;
            xpcbAvatar.BackColor = Color.Transparent;
            xlblCongratulations.Parent = xpctbxBackground;
            xlblCongratulations.BackColor = Color.Transparent;
            xlblFinishing.Parent = xpctbxBackground;
            xlblFinishing.BackColor = Color.Transparent;
            xlblScoreText.Parent = xpctbxBackground;
            xlblScoreText.BackColor = Color.Transparent;
            xlblThanks.Parent = xpctbxBackground;
            xlblThanks.BackColor = Color.Transparent;
        }

        private void ShowHidePreviousScore()
        {
            if (LoginScreen.userFound == false)
            {
                xbtnLeaderboard.Hide();
            }
            else
            {
                xbtnLeaderboard.Show();
            }
        }

        private void SaveDetails(bool saveFiles)
        {
            if (saveFiles == true)
            {
                SaveLastScore();
                SavePlayerDetails();
            }
        }

        private void SaveLastScore()
        {
            Serializer.SerializePlayer(MenuScreen.Player);
        }

        private void SavePlayerDetails()
        {
            string filePath = "previousscores.txt";
            FileStream fs;
            StreamWriter sw;

            try
            {
                if (!File.Exists(filePath))
                {
                    fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);
                }
                else
                {
                    fs = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                }

                sw = new StreamWriter(fs);
                sw.WriteLine($"{MenuScreen.Player.username}~{MenuScreen.Player.score}~{QuestionTickboxScreen.TickBoxQuestionCount + QuestionRadioButtonScreen.RadioQuestionCount + QuestionDragAndDropScreen.dragAndDropQuestionCount}");
                sw.Close();
                fs.Close();
            }
            catch (Exception) //(Exception ex)
            {
                MessageBox.Show($"Failed to save score", "Error"); //($"User details not found", "Error");
            }
        }

        private void xbtnMenu_Click(object sender, EventArgs e)
        {
            MenuScreen.Player.ResetPlayer();

            Player deserializedPlayer = Serializer.DeserializePlayer();
            string username = ($"{deserializedPlayer.username}");
            MenuScreen menuScreen = new MenuScreen(username);
            menuScreen.MdiParent = this.ParentForm;
            menuScreen.Dock = DockStyle.Fill;
            menuScreen.Show();
            this.Close();
        }

        private void xbtnLeaderboard_Click(object sender, EventArgs e)
        {
            LeaderboardScreen previousScoresScreen = new LeaderboardScreen();
            previousScoresScreen.MdiParent = this.ParentForm;
            previousScoresScreen.Dock = DockStyle.Fill;
            previousScoresScreen.Show();
            this.Close();
        }

        private void xbtnExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}