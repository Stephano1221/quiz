﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz5110
{
    public partial class QuestionDragAndDropScreen : Form
    {
        //Todo: Switch images/text to computer hardware
        public static int dragAndDropQuestionCount;
        private System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();

        public QuestionDragAndDropScreen()
        {
            InitializeComponent();
            SetAvatar();
            SetTimer();
            AllowDropping();
            dragAndDropQuestionCount = 3;
            xlblScore.Text = ($"Score: {MenuScreen.Player.score}");
        }

        private int _correctAnswers = 0;

        private void SetAvatar()
        {
            if (AvatarSelectScreen.avatarName == "xpcbAvatar1")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar1;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar2")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar2;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar3")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar3;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar4")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar4;
                xpcbAvatar.Refresh();
            }
        }

        private void SetQuiz()
        {
            timer.Stop();

            if (HolderForm.QuizNumber == 1)
            {
                dragAndDropQuestionCount = 0;
                NextQuestionType();
            }
            else if (HolderForm.QuizNumber == 2)
            {
                dragAndDropQuestionCount = 0;
                NextQuestionType();
            }
            else if (HolderForm.QuizNumber == 3)
            {
                dragAndDropQuestionCount = 3;
            }
        }

        private void SetTimer()
        {
            timer.Tick += new EventHandler(Timer_Tick);
            timer.Interval = 2;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            SetQuiz();
        }

        private void AllowDropping()
        {
            xpcbWindows.AllowDrop = true;
            xpcbSharepoint.AllowDrop = true;
            xpcbVisualStudio.AllowDrop = true;
        }

        private void xControlGrabbed(object sender, MouseEventArgs e)
        {
            Label selectedLabel = (Label)sender;
            selectedLabel.DoDragDrop(selectedLabel.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void xAllowDragDropCopy(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void xWindows_DragDrop(object sender, DragEventArgs e)
        {
            string result = (string)e.Data.GetData(DataFormats.Text);

            if (result == "Windows")
            {
                UpdateScoreAndLabel();
                xlblWindows.Visible = false;
                xpcbWindows.Visible = false;
            }
            else
            {
                xpcbWindows.Visible = false;
            }
        }

        private void xSharepoint_DragDrop(object sender, DragEventArgs e)
        {
            string result = (string)e.Data.GetData(DataFormats.Text);

            if (result == "Sharepoint")
            {
                UpdateScoreAndLabel();
                xlblSharepoint.Visible = false;
                xpcbSharepoint.Visible = false;
            }
            else
            {
                xpcbSharepoint.Visible = false;
            }
        }

        private void xVisualStudio_DragDrop(object sender, DragEventArgs e)
        {
            string result = (string)e.Data.GetData(DataFormats.Text);

            if (result == "Visual Studio")
            {
                UpdateScoreAndLabel();
                xlblVisualStudio.Visible = false;
                xpcbVisualStudio.Visible = false;
            }
            else
            {
                xpcbVisualStudio.Visible = false;
            }
        }

        private void xLabel_DragDrop(object sender, DragEventArgs e)
        {
            Label label = (Label)sender;
            label.Hide();
        }

        private void UpdateScoreAndLabel()
        {
            _correctAnswers++;
            MenuScreen.Player.IncreaseScore();
            xlblScore.Text = ($"Score: {MenuScreen.Player.score}");

            if (_correctAnswers == 3)
            {
                NextQuestionType();
            }
        }

        private void NextQuestionType()
        {
            HolderForm.CurrentQuestionTypeNumber++;

            if (HolderForm.CurrentQuestionTypeNumber == HolderForm.TickBoxPosition)
            {
                QuestionTickboxScreen tickboxScreen = new QuestionTickboxScreen();
                tickboxScreen.MdiParent = this.ParentForm;
                tickboxScreen.Dock = DockStyle.Fill;
                tickboxScreen.Show();
                this.Close();
            }
            else if (HolderForm.CurrentQuestionTypeNumber == HolderForm.RadioPosition)
            {
                QuestionRadioButtonScreen radioButtonScreen = new QuestionRadioButtonScreen();
                radioButtonScreen.MdiParent = this.ParentForm;
                radioButtonScreen.Dock = DockStyle.Fill;
                radioButtonScreen.Show();
                this.Close();
            }
            else if (HolderForm.CurrentQuestionTypeNumber == HolderForm.DragAndDropPosition)
            {
                QuestionDragAndDropScreen dragAndDropScreen = new QuestionDragAndDropScreen();
                dragAndDropScreen.MdiParent = this.ParentForm;
                dragAndDropScreen.Dock = DockStyle.Fill;
                dragAndDropScreen.Show();
                this.Close();
            }
            else if (HolderForm.CurrentQuestionTypeNumber == 4)
            {
                EndScreen endScreen = new EndScreen(true); //EndScreen();
                endScreen.MdiParent = this.ParentForm;
                endScreen.Dock = DockStyle.Fill;
                endScreen.Show();
                this.Close();
            }
        }
    }
}