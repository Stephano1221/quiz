﻿namespace Quiz5110
{
    partial class LoginScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xlblRegister = new System.Windows.Forms.Label();
            this.xrdbtnTeacher = new System.Windows.Forms.RadioButton();
            this.xrdbtnStudent = new System.Windows.Forms.RadioButton();
            this.xlblAccountType = new System.Windows.Forms.Label();
            this.xbtnLogin = new System.Windows.Forms.Button();
            this.xtxtbxPassword = new System.Windows.Forms.TextBox();
            this.xlblPassword = new System.Windows.Forms.Label();
            this.xtxtbxUsername = new System.Windows.Forms.TextBox();
            this.xlblUsername = new System.Windows.Forms.Label();
            this.xlblLogin = new System.Windows.Forms.Label();
            this.xpctbxRightArrow = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxRightArrow)).BeginInit();
            this.SuspendLayout();
            // 
            // xlblRegister
            // 
            this.xlblRegister.AutoSize = true;
            this.xlblRegister.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xlblRegister.Location = new System.Drawing.Point(245, 248);
            this.xlblRegister.Name = "xlblRegister";
            this.xlblRegister.Size = new System.Drawing.Size(46, 13);
            this.xlblRegister.TabIndex = 6;
            this.xlblRegister.Text = "Register";
            this.xlblRegister.Click += new System.EventHandler(this.xlblRegisterText_Click);
            // 
            // xrdbtnTeacher
            // 
            this.xrdbtnTeacher.AutoSize = true;
            this.xrdbtnTeacher.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xrdbtnTeacher.Location = new System.Drawing.Point(12, 49);
            this.xrdbtnTeacher.Name = "xrdbtnTeacher";
            this.xrdbtnTeacher.Size = new System.Drawing.Size(65, 17);
            this.xrdbtnTeacher.TabIndex = 15;
            this.xrdbtnTeacher.Text = "Teacher";
            this.xrdbtnTeacher.UseVisualStyleBackColor = true;
            this.xrdbtnTeacher.CheckedChanged += new System.EventHandler(this.AccountTypeChanged);
            // 
            // xrdbtnStudent
            // 
            this.xrdbtnStudent.AutoSize = true;
            this.xrdbtnStudent.Checked = true;
            this.xrdbtnStudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xrdbtnStudent.Location = new System.Drawing.Point(12, 26);
            this.xrdbtnStudent.Name = "xrdbtnStudent";
            this.xrdbtnStudent.Size = new System.Drawing.Size(62, 17);
            this.xrdbtnStudent.TabIndex = 14;
            this.xrdbtnStudent.TabStop = true;
            this.xrdbtnStudent.Text = "Student";
            this.xrdbtnStudent.UseVisualStyleBackColor = true;
            this.xrdbtnStudent.CheckedChanged += new System.EventHandler(this.AccountTypeChanged);
            // 
            // xlblAccountType
            // 
            this.xlblAccountType.AutoSize = true;
            this.xlblAccountType.Location = new System.Drawing.Point(12, 9);
            this.xlblAccountType.Name = "xlblAccountType";
            this.xlblAccountType.Size = new System.Drawing.Size(77, 13);
            this.xlblAccountType.TabIndex = 7;
            this.xlblAccountType.Text = "Account Type:";
            // 
            // xbtnLogin
            // 
            this.xbtnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnLogin.Location = new System.Drawing.Point(280, 300);
            this.xbtnLogin.Name = "xbtnLogin";
            this.xbtnLogin.Size = new System.Drawing.Size(80, 30);
            this.xbtnLogin.TabIndex = 13;
            this.xbtnLogin.Text = "Login";
            this.xbtnLogin.UseVisualStyleBackColor = true;
            this.xbtnLogin.Click += new System.EventHandler(this.xbtnLogin_Click);
            // 
            // xtxtbxPassword
            // 
            this.xtxtbxPassword.Location = new System.Drawing.Point(248, 225);
            this.xtxtbxPassword.MaxLength = 18;
            this.xtxtbxPassword.Name = "xtxtbxPassword";
            this.xtxtbxPassword.Size = new System.Drawing.Size(143, 20);
            this.xtxtbxPassword.TabIndex = 12;
            this.xtxtbxPassword.UseSystemPasswordChar = true;
            this.xtxtbxPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xKeyPress);
            // 
            // xlblPassword
            // 
            this.xlblPassword.AutoSize = true;
            this.xlblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblPassword.Location = new System.Drawing.Point(245, 206);
            this.xlblPassword.Name = "xlblPassword";
            this.xlblPassword.Size = new System.Drawing.Size(68, 16);
            this.xlblPassword.TabIndex = 8;
            this.xlblPassword.Text = "Password";
            // 
            // xtxtbxUsername
            // 
            this.xtxtbxUsername.Location = new System.Drawing.Point(248, 159);
            this.xtxtbxUsername.MaxLength = 15;
            this.xtxtbxUsername.Name = "xtxtbxUsername";
            this.xtxtbxUsername.Size = new System.Drawing.Size(143, 20);
            this.xtxtbxUsername.TabIndex = 11;
            this.xtxtbxUsername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xKeyPress);
            // 
            // xlblUsername
            // 
            this.xlblUsername.AutoSize = true;
            this.xlblUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblUsername.Location = new System.Drawing.Point(245, 140);
            this.xlblUsername.Name = "xlblUsername";
            this.xlblUsername.Size = new System.Drawing.Size(71, 16);
            this.xlblUsername.TabIndex = 9;
            this.xlblUsername.Text = "Username";
            // 
            // xlblLogin
            // 
            this.xlblLogin.AutoSize = true;
            this.xlblLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblLogin.Location = new System.Drawing.Point(270, 80);
            this.xlblLogin.Name = "xlblLogin";
            this.xlblLogin.Size = new System.Drawing.Size(96, 37);
            this.xlblLogin.TabIndex = 10;
            this.xlblLogin.Text = "Login";
            // 
            // xpctbxRightArrow
            // 
            this.xpctbxRightArrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xpctbxRightArrow.Image = global::Quiz5110.Properties.Resources.RightArrow;
            this.xpctbxRightArrow.Location = new System.Drawing.Point(292, 292);
            this.xpctbxRightArrow.Name = "xpctbxRightArrow";
            this.xpctbxRightArrow.Size = new System.Drawing.Size(56, 45);
            this.xpctbxRightArrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpctbxRightArrow.TabIndex = 17;
            this.xpctbxRightArrow.TabStop = false;
            this.xpctbxRightArrow.Click += new System.EventHandler(this.xbtnLogin_Click);
            this.xpctbxRightArrow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.xpctbxRightArrow_MouseDown);
            this.xpctbxRightArrow.MouseEnter += new System.EventHandler(this.xpctbxRightArrow_MouseEnter);
            this.xpctbxRightArrow.MouseLeave += new System.EventHandler(this.xpctbxRightArrow_MouseLeave);
            this.xpctbxRightArrow.MouseUp += new System.Windows.Forms.MouseEventHandler(this.xpctbxRightArrow_MouseUp);
            // 
            // LoginScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.Controls.Add(this.xpctbxRightArrow);
            this.Controls.Add(this.xlblRegister);
            this.Controls.Add(this.xrdbtnTeacher);
            this.Controls.Add(this.xrdbtnStudent);
            this.Controls.Add(this.xlblAccountType);
            this.Controls.Add(this.xbtnLogin);
            this.Controls.Add(this.xtxtbxPassword);
            this.Controls.Add(this.xlblPassword);
            this.Controls.Add(this.xtxtbxUsername);
            this.Controls.Add(this.xlblUsername);
            this.Controls.Add(this.xlblLogin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LoginScreen";
            this.Text = "LoginScreen";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xKeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxRightArrow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label xlblRegister;
        private System.Windows.Forms.RadioButton xrdbtnTeacher;
        private System.Windows.Forms.RadioButton xrdbtnStudent;
        private System.Windows.Forms.Label xlblAccountType;
        private System.Windows.Forms.Button xbtnLogin;
        private System.Windows.Forms.TextBox xtxtbxPassword;
        private System.Windows.Forms.Label xlblPassword;
        private System.Windows.Forms.TextBox xtxtbxUsername;
        private System.Windows.Forms.Label xlblUsername;
        private System.Windows.Forms.Label xlblLogin;
        private System.Windows.Forms.PictureBox xpctbxRightArrow;
    }
}