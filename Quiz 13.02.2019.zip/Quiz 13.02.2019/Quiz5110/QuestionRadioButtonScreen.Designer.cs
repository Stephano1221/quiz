﻿namespace Quiz5110
{
    partial class QuestionRadioButtonScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xrdbtnAnswer4 = new System.Windows.Forms.RadioButton();
            this.xrdbtnAnswer3 = new System.Windows.Forms.RadioButton();
            this.xrdbtnAnswer2 = new System.Windows.Forms.RadioButton();
            this.xrdbtnAnswer1 = new System.Windows.Forms.RadioButton();
            this.xbtnNext = new System.Windows.Forms.Button();
            this.xlblScore = new System.Windows.Forms.Label();
            this.xlblRadioQuestionText = new System.Windows.Forms.Label();
            this.xpctbxRightArrow = new System.Windows.Forms.PictureBox();
            this.xpcbAvatar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxRightArrow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).BeginInit();
            this.SuspendLayout();
            // 
            // xrdbtnAnswer4
            // 
            this.xrdbtnAnswer4.AutoSize = true;
            this.xrdbtnAnswer4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xrdbtnAnswer4.Location = new System.Drawing.Point(335, 191);
            this.xrdbtnAnswer4.Name = "xrdbtnAnswer4";
            this.xrdbtnAnswer4.Size = new System.Drawing.Size(66, 17);
            this.xrdbtnAnswer4.TabIndex = 42;
            this.xrdbtnAnswer4.Text = "Answer4";
            this.xrdbtnAnswer4.UseVisualStyleBackColor = true;
            this.xrdbtnAnswer4.CheckedChanged += new System.EventHandler(this.xRadioButton_CheckedChanged);
            // 
            // xrdbtnAnswer3
            // 
            this.xrdbtnAnswer3.AutoSize = true;
            this.xrdbtnAnswer3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xrdbtnAnswer3.Location = new System.Drawing.Point(94, 191);
            this.xrdbtnAnswer3.Name = "xrdbtnAnswer3";
            this.xrdbtnAnswer3.Size = new System.Drawing.Size(66, 17);
            this.xrdbtnAnswer3.TabIndex = 41;
            this.xrdbtnAnswer3.Text = "Answer3";
            this.xrdbtnAnswer3.UseVisualStyleBackColor = true;
            this.xrdbtnAnswer3.CheckedChanged += new System.EventHandler(this.xRadioButton_CheckedChanged);
            // 
            // xrdbtnAnswer2
            // 
            this.xrdbtnAnswer2.AutoSize = true;
            this.xrdbtnAnswer2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xrdbtnAnswer2.Location = new System.Drawing.Point(335, 141);
            this.xrdbtnAnswer2.Name = "xrdbtnAnswer2";
            this.xrdbtnAnswer2.Size = new System.Drawing.Size(66, 17);
            this.xrdbtnAnswer2.TabIndex = 40;
            this.xrdbtnAnswer2.Text = "Answer2";
            this.xrdbtnAnswer2.UseVisualStyleBackColor = true;
            this.xrdbtnAnswer2.CheckedChanged += new System.EventHandler(this.xRadioButton_CheckedChanged);
            // 
            // xrdbtnAnswer1
            // 
            this.xrdbtnAnswer1.AutoSize = true;
            this.xrdbtnAnswer1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xrdbtnAnswer1.Location = new System.Drawing.Point(94, 142);
            this.xrdbtnAnswer1.Name = "xrdbtnAnswer1";
            this.xrdbtnAnswer1.Size = new System.Drawing.Size(66, 17);
            this.xrdbtnAnswer1.TabIndex = 39;
            this.xrdbtnAnswer1.Text = "Answer1";
            this.xrdbtnAnswer1.UseVisualStyleBackColor = true;
            this.xrdbtnAnswer1.CheckedChanged += new System.EventHandler(this.xRadioButton_CheckedChanged);
            // 
            // xbtnNext
            // 
            this.xbtnNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xbtnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xbtnNext.Location = new System.Drawing.Point(240, 296);
            this.xbtnNext.Name = "xbtnNext";
            this.xbtnNext.Size = new System.Drawing.Size(158, 54);
            this.xbtnNext.TabIndex = 38;
            this.xbtnNext.Text = "Next";
            this.xbtnNext.UseVisualStyleBackColor = true;
            this.xbtnNext.Click += new System.EventHandler(this.xbtnNext_Click);
            // 
            // xlblScore
            // 
            this.xlblScore.AutoSize = true;
            this.xlblScore.Location = new System.Drawing.Point(12, 9);
            this.xlblScore.Name = "xlblScore";
            this.xlblScore.Size = new System.Drawing.Size(38, 13);
            this.xlblScore.TabIndex = 35;
            this.xlblScore.Text = "Score:";
            // 
            // xlblRadioQuestionText
            // 
            this.xlblRadioQuestionText.AutoSize = true;
            this.xlblRadioQuestionText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlblRadioQuestionText.Location = new System.Drawing.Point(34, 56);
            this.xlblRadioQuestionText.Name = "xlblRadioQuestionText";
            this.xlblRadioQuestionText.Size = new System.Drawing.Size(103, 20);
            this.xlblRadioQuestionText.TabIndex = 36;
            this.xlblRadioQuestionText.Text = "QuestionText";
            // 
            // xpctbxRightArrow
            // 
            this.xpctbxRightArrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xpctbxRightArrow.Image = global::Quiz5110.Properties.Resources.RightArrow;
            this.xpctbxRightArrow.Location = new System.Drawing.Point(263, 279);
            this.xpctbxRightArrow.Name = "xpctbxRightArrow";
            this.xpctbxRightArrow.Size = new System.Drawing.Size(114, 89);
            this.xpctbxRightArrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpctbxRightArrow.TabIndex = 43;
            this.xpctbxRightArrow.TabStop = false;
            this.xpctbxRightArrow.Click += new System.EventHandler(this.xbtnNext_Click);
            this.xpctbxRightArrow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.xpctbxRightArrow_MouseDown);
            this.xpctbxRightArrow.MouseEnter += new System.EventHandler(this.xpctbxRightArrow_MouseEnter);
            this.xpctbxRightArrow.MouseLeave += new System.EventHandler(this.xpctbxRightArrow_MouseLeave);
            this.xpctbxRightArrow.MouseUp += new System.Windows.Forms.MouseEventHandler(this.xpctbxRightArrow_MouseUp);
            // 
            // xpcbAvatar
            // 
            this.xpcbAvatar.Location = new System.Drawing.Point(542, 12);
            this.xpcbAvatar.Name = "xpcbAvatar";
            this.xpcbAvatar.Size = new System.Drawing.Size(75, 75);
            this.xpcbAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.xpcbAvatar.TabIndex = 37;
            this.xpcbAvatar.TabStop = false;
            // 
            // QuestionRadioButtonScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.Controls.Add(this.xpctbxRightArrow);
            this.Controls.Add(this.xrdbtnAnswer4);
            this.Controls.Add(this.xrdbtnAnswer3);
            this.Controls.Add(this.xrdbtnAnswer2);
            this.Controls.Add(this.xrdbtnAnswer1);
            this.Controls.Add(this.xbtnNext);
            this.Controls.Add(this.xpcbAvatar);
            this.Controls.Add(this.xlblScore);
            this.Controls.Add(this.xlblRadioQuestionText);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "QuestionRadioButtonScreen";
            this.Text = "QuestionRadioScreen";
            ((System.ComponentModel.ISupportInitialize)(this.xpctbxRightArrow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xpcbAvatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton xrdbtnAnswer4;
        private System.Windows.Forms.RadioButton xrdbtnAnswer3;
        private System.Windows.Forms.RadioButton xrdbtnAnswer2;
        private System.Windows.Forms.RadioButton xrdbtnAnswer1;
        private System.Windows.Forms.Button xbtnNext;
        private System.Windows.Forms.PictureBox xpcbAvatar;
        private System.Windows.Forms.Label xlblScore;
        private System.Windows.Forms.Label xlblRadioQuestionText;
        private System.Windows.Forms.PictureBox xpctbxRightArrow;
    }
}