﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Quiz5110
{
    public partial class LoginScreen : Form
    {
        public static bool userFound = false;

        public LoginScreen()
        {
            InitializeComponent();
            HolderForm.comingFrom = "LoginScreen";
            userFound = false;
            xbtnLogin.Hide();
            xlblPassword.Hide();
            xtxtbxPassword.Hide();
            xlblRegister.Hide();
        }

        private void xlblRegisterText_Click(object sender, EventArgs e)
        {
            RegisterScreen registerScreen = new RegisterScreen(null);
            registerScreen.MdiParent = this.ParentForm;
            registerScreen.Dock = DockStyle.Fill;
            registerScreen.Show();
            this.Close();
        }

        private void xbtnLogin_Click(object sender, EventArgs e)
        {
            string username = xtxtbxUsername.Text;
            string password = xtxtbxPassword.Text;

            if (!username.All((char.IsLetter)) && xrdbtnStudent.Checked == true)
            {
                MessageBox.Show($"Only letters are allowed in the username field.", "Error");
                return;
            }
            if (password.Contains('~'))
            {
                MessageBox.Show($"Invalid character '~' in the password field.", "Error");
                return;
            }

            if (xrdbtnStudent.Checked == true)
            {
                if (!string.IsNullOrEmpty(username))
                {
                    AvatarSelectScreen avatarSelectScreen = new AvatarSelectScreen(username);
                    avatarSelectScreen.MdiParent = this.ParentForm;
                    avatarSelectScreen.Dock = DockStyle.Fill;
                    avatarSelectScreen.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show($"The username field is required.", "Error");
                }
            }
            else if (xrdbtnTeacher.Checked == true)
            {
                if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
                {
                    string filePath = "users.txt";
                    if (File.Exists(filePath))
                    {
                        StreamReader sr = new StreamReader(filePath);
                        userFound = false;

                        while(sr.Peek() >= 0)
                        {
                            string[] readElements = sr.ReadLine().Split('~');
                            if (username == readElements[0] && password == readElements[1])
                            {
                                userFound = true;
                                break;
                            }
                        }
                        sr.Close();

                        if (userFound == true)
                        {
                            AvatarSelectScreen avatarSelectScreen = new AvatarSelectScreen(username);
                            avatarSelectScreen.MdiParent = this.ParentForm;
                            avatarSelectScreen.Dock = DockStyle.Fill;
                            avatarSelectScreen.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show($"Incorrect username and/or password.", "Error");
                        }
                    }
                    else
                    {
                        MessageBox.Show($"No teacher accounts exist. Please register.", "Error");
                    }
                }
                else
                {
                    MessageBox.Show($"The username and password fields are required.", "Error");
                }
            }
        }

        private void xKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                xbtnLogin_Click(sender, e);
            }
        }

        private void xbtnLeaderboard_Click(object sender, EventArgs e)
        {
            LeaderboardScreen leaderboard = new LeaderboardScreen();
            leaderboard.MdiParent = this.ParentForm;
            leaderboard.Dock = DockStyle.Fill;
            leaderboard.Show();
            this.Close();
        }

        private void AccountTypeChanged(object sender, EventArgs e)
        {
            if (xrdbtnStudent.Checked == true && xrdbtnTeacher.Checked == false)
            {
                xlblPassword.Hide();
                xtxtbxPassword.Hide();
            }
            else if (xrdbtnStudent.Checked == false && xrdbtnTeacher.Checked == true)
            {
                xlblPassword.Show();
                xtxtbxPassword.Show();
            }

            if (!File.Exists("users.txt") && xrdbtnTeacher.Checked == true)
            {
                xlblRegister.Show();
            }
            else
            {
                xlblRegister.Hide();
            }
        }

        private void xpctbxRightArrow_MouseEnter(object sender, EventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrowHover;
        }

        private void xpctbxRightArrow_MouseLeave(object sender, EventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrow;
        }

        private void xpctbxRightArrow_MouseDown(object sender, MouseEventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrowClick;
        }

        private void xpctbxRightArrow_MouseUp(object sender, MouseEventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrow;
        }
    }
}