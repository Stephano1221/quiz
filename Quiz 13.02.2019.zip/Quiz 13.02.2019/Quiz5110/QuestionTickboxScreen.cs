﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz5110
{
    public partial class QuestionTickboxScreen : Form
    {
        public static int TickBoxQuestionCount = 0;
        private List<Question> _questions = new List<Question>();
        private List<int> questionOrder = new List<int>();
        private int _currentQuestion = 0;
        private int questionNumber = 0;
        private Random random = new Random();
        private System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();

        public QuestionTickboxScreen()
        {
            InitializeComponent();
            SetAvatar();
            SetQuiz();
            xbtnNext.Hide();
            xpctbxRightArrow.Hide();
            xlblScore.Text = ($"Score: {MenuScreen.Player.score}");
        }

        private void SetQuiz()
        {
            if (HolderForm.QuizNumber == 1)
            {
                Quiz1();
            }
            else if (HolderForm.QuizNumber == 2)
            {
                Quiz2();
            }
            else if (HolderForm.QuizNumber == 3)
            {
                Quiz3();
            }
        }

        private void SetAvatar()
        {
            if (AvatarSelectScreen.avatarName == "xpcbAvatar1")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar1;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar2")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar2;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar3")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar3;
                xpcbAvatar.Refresh();
            }
            else if (AvatarSelectScreen.avatarName == "xpcbAvatar4")
            {
                xpcbAvatar.Image = Properties.Resources.Avatar4;
                xpcbAvatar.Refresh();
            }
        }

        //Todo: Add ability to read and write questions to/from a text file. Use multidimensional arrays.
        private void Quiz1()
        {
            //Todo: Replace with questions from questions class
            _questions.Add(new Question("Expand the acronyms LAN and WAN",
                new[] { "Local Area Network", "Local Arrayed Network", "Wide Asynced Network", "Wide Area Network" }, 9));

            _questions.Add(new Question("Name three network topologies",
                new[] { "Bus Network", "Diamond Network", "Star Network", "Ring Network", "Bush Network", "Cage Network" }, 13));

            _questions.Add(new Question("State three advantages of a network",
                new[] { "Better security against\nhackers and viruses", "The same software can be\nrun on multiple systems", "Setting up and managing\na network is easy", "Shared data/files", "Shared hardware", "The hadware and cabling\nrequired is cheap" }, 26));

            _questions.Add(new Question("State three disadvantages of a network",
                new[] { "If the file server fails,\ndata might become innaccessible", "Viruses spread easier", "Data transfer is easier\nbetween systems", "Site-wide software licences\n can be cheaper", "Data is backed up on\non a file server", "Large networks often require\na network manager" }, 35));

            /*_questions.Add(new Question("What is meant by the term 'internet of things'?",
                new[] { "", "", "", "", "", "", "" }, 3));*/

            CheckIfQuestionsExist();
        }

        private void Quiz2()
        {
            _questions.Add(new Question("Explain the main hardware devices needed for a wireless connection",
                new[] { "A router provides a connection\nto the physical network", "A network interface card converts\nradio waves into\ndata and vice versa", "A network interface card provides\na connection to the internet", "A network interface card\nstores MAC addresses" }, 3));

            _questions.Add(new Question("State an advantage of Wi-Fi for a student",
                new[] { "Connection speeds might\nbe slower than cable", "Access to the school network\nfrom their smartphone", "Has a very limited range" }, 2));

            _questions.Add(new Question("State a disadvantage of Wi-Fi to a student",
                new[] { "Wi-Fi is cheaper and faster\nthan cellular data", "Doesn't require cables", "Certain educational sites might\nbe slow/blocked" }, 4));

            _questions.Add(new Question("What is a network interface cards purpose in a network?",
                new[] { "To convert data into radio waves", "To convert radio waves into data", "To store the MAC address\n of other computers", "To act as a firewall" }, 3));

            _questions.Add(new Question("What is the difference between the internet and intranet?",
                new[] { "The internet connects computers locally,\nwhile the intranet connects them globally", "The internet contains search engines,\nwhile the intranet contains websites", "The internet connects computers gobally,\nwhile the intranet connects them locally", "The internet is country-specific,\nwhile the intranet is global" }, 4));

            CheckIfQuestionsExist();
        }

        private void Quiz3()
        {
            /*_questions.Add(new Question("State three factors which can influence the speed of processing",
                new[] { "", "", "", "" }, 1));*/
            _questions.Add(new Question("What is the purpose of the CPU?",
                new[] { "To store long-term data", "To provide power to\nother components", "To boot the system", "To perform arithmetic/logical\ncalculations" }, 8));

            _questions.Add(new Question("Name four storage devices",
                new[] { "Motherboard", "Solid State Drive", "Hard Disk Drive", "Magnetic Tape Drive", "Capture Card", "Optical Disk" }, 46));

            _questions.Add(new Question("What is the difference between RAM and ROM?",
                new[] { "RAM is volatile,\nROM is non-volatile", "ROM is read only,\nRAM is rewritable", "RAM is non-volatile,\nROM is volatile", "RAM is read only,\nROM is rewritable" }, 3));

            _questions.Add(new Question("Explain the purpose of cache memory",
                new[] { "To store long-term data", "To speed up the fetching\nof data by the CPU", "To store irrelevant data", "To keep a record of\ninstalled programs" }, 2));

            _questions.Add(new Question("What is the storage size of a standard DVD?",
                new[] { "2.3GB", "9.4GB", "5.9GB", "4.7GB" }, 8));

            CheckIfQuestionsExist();
        }

        private void CheckIfQuestionsExist()
        {
            TickBoxQuestionCount = _questions.Count();
            if (TickBoxQuestionCount > 0)
            {
                SetQuestionOrder();
                NextQuestion();
            }
            else
            {
                timer.Tick += new EventHandler(Timer_Tick);
                timer.Interval = 2;
                timer.Start();
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            NextQuestionType();
        }

        private int RandomNumber()
        {
            lock (random)
            {
                return random.Next(0, TickBoxQuestionCount);
            }
        }

        private void NextQuestion()
        {
            if (TickBoxQuestionCount == 0)
            {
                NextQuestionType();
            }
            string[] answers = _questions[_currentQuestion].Answers;

            xchkbxAnswer1.Hide();
            xchkbxAnswer2.Hide();
            xchkbxAnswer3.Hide();
            xchkbxAnswer4.Hide();
            xchkbxAnswer5.Hide();
            xchkbxAnswer6.Hide();

            if (answers.ElementAtOrDefault(0) != null)
            {
                xlblQuestionTwoText.Text = _questions[_currentQuestion].QuestionText;
                xchkbxAnswer1.Text = answers[0];
                xchkbxAnswer1.Show();
            }
            if (answers.ElementAtOrDefault(1) != null)
            {
                xchkbxAnswer2.Text = answers[1];
                xchkbxAnswer2.Show();
            }
            if (answers.ElementAtOrDefault(2) != null)
            {
                xchkbxAnswer3.Text = answers[2];
                xchkbxAnswer3.Show();
            }
            if (answers.ElementAtOrDefault(3) != null)
            {
                xchkbxAnswer4.Text = answers[3];
                xchkbxAnswer4.Show();
            }
            if (answers.ElementAtOrDefault(4) != null)
            {
                xchkbxAnswer5.Text = answers[4];
                xchkbxAnswer5.Show();
            }
            if (answers.ElementAtOrDefault(5) != null)
            {
                xchkbxAnswer6.Text = answers[5];
                xchkbxAnswer6.Show();
            }
        }

        private void xbtnNext_Click(object sender, EventArgs e)
        {
            SetSelectedAnswers();
        }

        private void SetSelectedAnswers()
        {
            int answer = 0;
            if (xchkbxAnswer1.Checked == true)
            {
                answer = answer + 1;
            }
            if (xchkbxAnswer2.Checked == true)
            {
                answer = answer + 2;
            }
            if (xchkbxAnswer3.Checked == true)
            {
                answer = answer + 4;
            }
            if (xchkbxAnswer4.Checked == true)
            {
                answer = answer + 8;
            }
            if (xchkbxAnswer5.Checked == true)
            {
                answer = answer + 16;
            }
            if (xchkbxAnswer6.Checked == true)
            {
                answer = answer + 32;
            }
            xchkbxAnswer1.Checked = false;
            xchkbxAnswer2.Checked = false;
            xchkbxAnswer3.Checked = false;
            xchkbxAnswer4.Checked = false;
            xchkbxAnswer5.Checked = false;
            xchkbxAnswer6.Checked = false;
            CheckAnswer(answer);
        }

        private void SetQuestionOrder()
        {
            for (int i = 0; i < TickBoxQuestionCount; i++)
            {
                questionOrder.Add(RandomNumber());
                while (questionOrder.IndexOf(questionOrder.ElementAtOrDefault(i)) != i)
                {
                    questionOrder[i] = RandomNumber();
                }
            }
            _currentQuestion = questionOrder.ElementAtOrDefault(0);
        }

        private void CheckAnswer(int answer)
        {
            if (TickBoxQuestionCount > 0)
            {
                if (answer == _questions[_currentQuestion].CorrectAnswerPosition)
                {
                    MenuScreen.Player.IncreaseScore();
                    xlblScore.Text = ($"Score: {MenuScreen.Player.score}");
                }

                questionNumber++;
                _currentQuestion = questionOrder.ElementAtOrDefault(questionNumber);
            }

            if (questionNumber < _questions.Count)
            {
                NextQuestion();
            }
            else
            {
                NextQuestionType();
            }
        }

        private void NextQuestionType()
        {
            HolderForm.CurrentQuestionTypeNumber++;

            if (HolderForm.CurrentQuestionTypeNumber == HolderForm.TickBoxPosition)
            {
                QuestionTickboxScreen tickboxScreen = new QuestionTickboxScreen();
                tickboxScreen.MdiParent = this.ParentForm;
                tickboxScreen.Dock = DockStyle.Fill;
                tickboxScreen.Show();
                this.Close();
            }
            else if (HolderForm.CurrentQuestionTypeNumber == HolderForm.RadioPosition)
            {
                QuestionRadioButtonScreen radioButtonScreen = new QuestionRadioButtonScreen();
                radioButtonScreen.MdiParent = this.ParentForm;
                radioButtonScreen.Dock = DockStyle.Fill;
                radioButtonScreen.Show();
                this.Close();
            }
            else if (HolderForm.CurrentQuestionTypeNumber == HolderForm.DragAndDropPosition)
            {
                QuestionDragAndDropScreen dragAndDropScreen = new QuestionDragAndDropScreen();
                dragAndDropScreen.MdiParent = this.ParentForm;
                dragAndDropScreen.Dock = DockStyle.Fill;
                dragAndDropScreen.Show();
                this.Close();
            }
            else if (HolderForm.CurrentQuestionTypeNumber == 4)
            {
                EndScreen endScreen = new EndScreen(true); //EndScreen();
                endScreen.MdiParent = this.ParentForm;
                endScreen.Dock = DockStyle.Fill;
                endScreen.Show();
                this.Close();
            }
        }

        private void xpctbxRightArrow_MouseEnter(object sender, EventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrowHover;
        }

        private void xpctbxRightArrow_MouseLeave(object sender, EventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrow;
        }

        private void xpctbxRightArrow_MouseDown(object sender, MouseEventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrowClick;
        }

        private void xpctbxRightArrow_MouseUp(object sender, MouseEventArgs e)
        {
            xpctbxRightArrow.Image = Properties.Resources.RightArrow;
        }

        private void xAnswers_CheckedChanged(object sender, EventArgs e)
        {
            if (xchkbxAnswer1.Checked == true || xchkbxAnswer2.Checked == true || xchkbxAnswer3.Checked == true || xchkbxAnswer4.Checked == true || xchkbxAnswer5.Checked == true || xchkbxAnswer6.Checked == true)
            {
                xpctbxRightArrow.Show();
            }
            else
            {
                xpctbxRightArrow.Hide();
            }
        }
    }
}